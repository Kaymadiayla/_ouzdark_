<?php session_start();
$_SESSION['Email'] = 'ousmandoye1234@gmail.com';2
 ?>
 <?php if (isset($_SESSION['create_pass'])): ?>
   

<!-- connexion a la base de donnée -->
<?php  $user = 'id19723717_ousmane_ndoye';
$pass = 'Mwrhv.ouzdark.2004';
try
{
  $db = new PDO('mysql:host=localhost;dbname=id19723717_utilisateurs;charset=utf8', $user, $pass,
[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
  
}
catch (PDOException $e)
{
        print('Erreur : ') . $e->getMessage() . "<br/>";
        die;
}

?>



 <?php if(isset($_SESSION['Email'])): ?>
 <!-- on recupere les informations de l'utilisateurs -->
 <?php $information_recovery = $db->prepare('SELECT * FROM Utilisateurs WHERE Email = ? ORDER BY `ID` ASC LIMIT 1'); ?>
 <?php $execution = $information_recovery->execute(array(trim($_SESSION['Email']))); ?>
 <?php  ?>
 <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Ouzdark</title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css.folder/bienvenue.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>
  <body style="font-family: Nunito;">


<div  class="div">
  <div  class="div1">
  
</div>
</div>
   <?php $fetch = $information_recovery->rowCount(); ?>
   <!-- <?php if($execution): ?> si la recuperation des informations s'est bien passé -->
   <!-- <?php if($fetch > 0): ?>  si l'email est inscris -->
<!-- recuperation des infos -->
 <?php while($user = $information_recovery->fetch()){ ?>

<div class="mx-auto create-pswd bg-white shadow-lg col-10 col-sm-8 col-md-6 col-lg-5 col-xl-4">
  <center><span class="black-blue-color">Hey, <strong><?php echo $user['Username']; ?></strong>!!</span></center>
 <?php $_SESSION['Prenom_R'] = $user['Prenom']; ?>
 <?php $_SESSION['Nom_R'] = $user['Nom']; ?>
 <?php $_SESSION['Username'] = $user['Username']; ?>
  <center>
    <span class="black-blue-color" style="font-size: 12px;">
    Il vous faut un mot de passe pour continuer
    <br>
    <span style="color: #f14a69;">
      Une fois les mots de passe entrés, vous pouvez les voir en fesant un double clique sur la zone de texte a visionner
    </span>
  </span>
  </center>
  <br>
  <form action="bienvenue.php" method="POST">
<div class="form-floating mb-3">
  <input minlength="8" maxlength="100" name="password" type="password" ondblclick="if(this.type == 'password'){ this.type='text' }else{ this.type='password' }"  class="password form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Mot de passe</label>
</div>
<div class="form-floating">
  <input name="passwordc" ondblclick="if(this.type == 'password'){ this.type='text' }else{ this.type='password' }" type="password" class="passwordc form-control" id="floatingPassword" placeholder="Password">
  <label for="floatingPassword">Confirmer le mot de passe</label>
</div>
<br>
<div class="form-floating">
  <input name="create" value="Enregistrer" style="color: white; background: #f14a69;" type="submit" class="form-control" id="floatingPassword" placeholder="Password">

</div>
</form>
  </div>
<?php } ?>
<?php else: ?>
  <script type="text/javascript">
    alert('Veuiller vous inscrire avant d\'acceder a cette page');
    document.location.href = 'http://ouzdark.space';
  </script>
<?php endif ?>
<!-- <?php else: ?> s'il y-a eu erreur lors de l'execution de la requette -->
<script type="text/javascript">
  alert('Une erreur est survenue lors de la recupération des informations, cliquer sur le bouton ci contre pour re-essayer, si l\'erreur persiste alors n\'hesitez pas a nous contacter par whatsApp ');
  document.location.reload();
</script>
<?php endif ?>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </body>
  </html>
<?php else: ?>
 <script type="text/javascript">
   document.location.href = 'http://ouzdark.space';
 </script>
  <?php endif ?>





  <!-- 
===================================
ANIMATIONS
===================================
 -->
 <?php if (!isset($_POST['create'])): ?>
   

<script> 
  let divp = document.querySelector('div.div');
  let div1 = document.querySelector('div.div1');
  let div = document.querySelector('div.create-pswd');
  divp.style.transitionDuration = '2s';
  div1.style.transitionDuration = '2s';
  divp.style.marginTop = '-1000px';
  div1.style.transitionDuration = '-1000px';
  setTimeout(function(){
  divp.style.transitionDuration = '2s';
  div1.style.transitionDuration = '2s';
  setTimeout(function(){
    divp.style.marginTop = '-20px'
  setTimeout(function(){
 div1.style.marginTop = '-100px';
  setTimeout(function(){
   div.style.transitionDuration = '2s';
   div.style.left = 0;
   }, 1000)
  }, 1000)
  }, 500)
}, 700)
  div.style.left = '-2000px';
  div.style.transitionDuration = '2s';
  

</script> 
  <?php endif ?>


 <?php if(isset($_POST['create'])): ?>

  <?php if (isset($_POST['password'])): ?>
    

<?php if (isset($_POST['passwordc'])): ?>
  
<script type="text/javascript">
  let password = document.querySelector('input.password');
  let passwordc = document.querySelector('input.passwordc');
  passwordc.value = '<?php echo trim($_POST['passwordc']); ?>';
  password.value = '<?php echo trim($_POST['password']); ?>';
</script>
<!-- <?php if (strlen(trim($_POST['password'])) > 7): ?> si le mot de passe contient au minimum 8 caractéres  -->


<?php if (trim($_POST['password']) == trim($_POST['passwordc'])): ?>
<!-- on enregistre le mot de passe dans la base de donnée -->
<?php $save_pass = $db->prepare('UPDATE Utilisateurs SET Mot_de_passe = ? WHERE Email = ?'); ?>
<?php $saving = $save_pass->execute(array(trim($_POST['password']), $_SESSION['Email'])); ?>
<?php if ($saving): ?>
  <?php $_SESSION['Email_R'] = $_SESSION['Email']; ?>
  <?php unset($_SESSION['create_pass']); ?>
  <script type="text/javascript">
    let divp = document.querySelector('div.div');
  let div1 = document.querySelector('div.div1');
  let div = document.querySelector('div.create-pswd');
  setTimeout(function(){
     divp.style.transitionDuration = '2s';
  div1.style.transitionDuration = '2s';
  divp.style.marginTop = '-1000px';
 setTimeout(function(){
 div.style.transitionDuration = '1s';
 div.style.left = '-2000px';
 setTimeout(function(){
 document.location.href = 'bienvenue1.php';
 }, 1000)
 }, 2000)
  div.style.transitionDuration = '2s';
}, 1000)
  </script>

  
  <?php else: ?>  
    <script type="text/javascript">
     alert('Une erreur est survenu veuiller reessayer');
    </script>
<?php endif ?>
    
  <?php else: ?>
    <script type="text/javascript">
     alert('Les deux mots de passe ne sont pas identiques, veuiller bien verifier');
    </script>
<?php endif ?>


  <?php else: ?>
    <script type="text/javascript">
      alert('Le mot de passe doit contenir au moins 8 caractéres et ne dois pas contenir d\'espaces en debut et fin, car celles-ci sont supprimé avant l\'enregistrement du mot de passe');
    </script>
<?php endif ?>

<?php endif ?>

  <?php endif ?>
  <?php endif ?>

  <!-- si l'utilisateur n'est pas la pour creer un mot de passe alors renvoyons la -->
  <?php else: ?>
    <script type="text/javascript">
      document.location.href = 'Home.php';
    </script>
   <?php endif ?>