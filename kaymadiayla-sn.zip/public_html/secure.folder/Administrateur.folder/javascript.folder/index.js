let homeIcon = document.querySelector('div.Home-icon-box');
let action1 = document.querySelector('div.action-i-box-1');
let action2 = document.querySelector('div.action-i-box-2');
let action3 = document.querySelector('div.action-i-box-3');
homeIcon.style.transform = 'translateY(-400px)';

action1.style.transform = 'translateX(-1400px)'
action2.style.transform = 'translateX(-1400px)'
action3.style.transform = 'translateX(-1400px)'


setTimeout(function(){
action1.style.transitionDuration = '1s'
action2.style.transitionDuration = '1s'
action3.style.transitionDuration = '1s'
homeIcon.style.transitionDuration = '1s'
setTimeout(function(){
homeIcon.style.transform = 'translateY(0)';
homeIcon.style.left = '0';
homeIcon.style.right = '0';
setTimeout(function(){
action3.style.transform = 'translateX(0)'
setTimeout(function(){
action2.style.transform = 'translateX(0)'
setTimeout(function(){
action1.style.transform = 'translateX(0)'
}, 500)
}, 500)
}, 500)
}, 500)
}, 500)