<?php session_start(); ?>

<?php $_SESSION['AD'] = true; ?>
  

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title></title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <?php if(isset($_SESSION['AD'])): ?> <link rel="stylesheet" type="text/css" href="css.folder/index1.css"> <?php endif ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>
  <?php if (isset($_SESSION['AD'])): ?>
  <body style="font-family: Nunito;">

 <script type="text/javascript">
  

   // fonction de reaction au clique d'un bouton
 
function return_2_3_on_these_initial_place(){
let action2_ = document.querySelector('div.action-i-box-2');
let action3_ = document.querySelector('div.action-i-box-3');
let action1_ = document.querySelector('div.action-i-box-1');
let btn_off = document.querySelector('button.btn-off');
btn_off.style.visibility = 'visible';
action2_.style.transitionDuration = '1s'
action3_.style.transitionDuration = '1s'
action1_.style.transitionDuration = '3s'
action2_.style.transform = 'translateX(-1400px)'
action3_.style.transform = 'translateX(-1400px)'
action1_.style.position = 'absolute'
action1_.style.left = '0';
action1_.style.right = '0';
<?php $_SESSION['CH'] = true; ?>
setTimeout(function(){
document.location.href = 'Publication.php';
}, 500)


}

function return_1_3_on_these_initial_place(){
 let action2_ = document.querySelector('div.action-i-box-2');
let action3_ = document.querySelector('div.action-i-box-3');

let action1_ = document.querySelector('div.action-i-box-1');

let btn_off = document.querySelector('button.btn-off');
btn_off.style.visibility = 'visible';
btn_off.style.transform = 'translateY(40px)'
action1_.style.transitionDuration = '1s'
action3_.style.transitionDuration = '1s'
//< principal
action2_.style.transitionDuration = '3s'
// >principal
action1_.style.transform = 'translateX(-1400px)'
action3_.style.transform = 'translateX(-1400px)'
//< principal
action2_.style.position = 'absolute'
action2_.style.left = '0';
action2_.style.right = '0';
//> principal

setTimeout(function(){
document.location.href = 'gestion.php';
}, 500)


}

function return_2_1_on_these_initial_place(){
let action2_ = document.querySelector('div.action-i-box-2');
let action3_ = document.querySelector('div.action-i-box-3');
//< principal
let action1_ = document.querySelector('div.action-i-box-1');
//> principal
let btn_off = document.querySelector('button.btn-off');
btn_off.style.visibility = 'visible';
action2_.style.transitionDuration = '1s'
action1_.style.transitionDuration = '1s'
//< principal
action3_.style.transitionDuration = '3s'
// >principal
action2_.style.transform = 'translateX(-1400px)'
action1_.style.transform = 'translateX(-1400px)'
//< principal
action3_.style.position = 'absolute'
action3_.style.left = '0';
action3_.style.right = '0';
//> principal

setTimeout(function(){
document.location.href = 'organiser.php';
}, 500)


}

 </script>



  	<center>
<div onclick="document.location.href='http://ouzdark.space/Home.php'" class="Home-icon-box">
	<i class="Home-icon fs-1 bi bi-house"></i>
	<h6 style="color: white;" >Home</h6>
</div>
</center>
<center>

 <div align="center" style="" class="col-12 col-sm-7 col-md-7 col-lg-4 col-xl-4 col-xxl-4 text-center action d-flex">
<div>
	
</div>
<div class="action-i-box-1">
 	<div onclick="return_2_3_on_these_initial_place()" class="action-1">
 		<i class="fs-1 bi bi-window-plus"></i>
 	</div>
 	<br>
 	<div class="text-center">
 		Publier
 	</div>
</div>
<div onclick="return_1_3_on_these_initial_place()" class="action-i-box-2">
 	<div class="action-2">
 		<i class="fs-1 bi bi-person"></i>
 	</div>
 	<br>
 	<div class="text-center">
 		Gestion des utilisateurs
 	</div>
</div>
<div onclick="return_2_1_on_these_initial_place()"  class="action-i-box-3">
 	<div class="action-3">
 		<i class="fs-1 bi bi-bezier"></i>
 	</div>
 	<br>
 	<div class="text-center">
 		Organiser
 	</div></div>
 	</div>
 	</center>
 </div>

<center> 
  <button style="filter: opacity(70%);" class=" mt-2 btn-off btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">Plus</button>
  <style type="text/css">
    .btn-off{
      visibility: hidden;
    }
  </style>
</center>
<div class="off1 offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Options</h5>
    <button  type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">


<div class="list-group">
  
  <button type="button" class="list-group-item list-group-item-action"><i class="fs-4 bi bi-window-plus"></i> &ensp; Publier</button>
  <button type="button" class="list-group-item list-group-item-action"><i class="fs-4 bi bi-person"></i> &ensp; Gestion</button>
  <button type="button" class="list-group-item list-group-item-action"><i class="fs-4 bi bi-bezier"></i> &ensp; Organiser</button> 
  <button type="button" class="list-group-item list-group-item-action"> /////////// </button> 
  <button onclick="document.location.href('http://ouzdark.space/secure.folder/Administrateur.folder/')" type="button" class="list-group-item list-group-item-action"><i  class="bi bi-arrow-clockwise"></i> &ensp; Rafraichir</button>
  
</div>
  </div>
</div>


 <!-- lien javascript boostrap -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="javascript.folder/index.js" defer ></script>

</body>
<?php else: ?>
<div class="mt-5 text-center mx-auto alert alert-danger col-10 col-sm-7 col-md-7 col-lg-5 col-xl-5" role="alert">
  Acces denied
</div>
<?php endif ?>
</html>


