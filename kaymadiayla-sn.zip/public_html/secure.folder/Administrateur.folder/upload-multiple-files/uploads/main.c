#include <stdio.h>

int moyennneTableau(int n, int Tab[]){
    int i ;
    float moynne;

    for (i=0 ;i<n;i++){
        moynne =moynne +Tab[i];

    }
    return moynne/n;
}



