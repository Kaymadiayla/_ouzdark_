#include <stdio.h>
void main(){
    int a, b, c= 0, i,max, min;
    printf("Entrer deux entier ");
    scanf("%d %d", &a,& b);
    for (i=0; i<b ; i++){
        if (a>= b)
        {
            /* code */
            max = b, min=a;

        }
        if (a <b)
        {
            /* code */
            max = a, min=b;
        }
        while (min<=main && min!=0)

        {
            max = max - min;
            i++;
            print("%d",i);
        }
        

        
    }
}