// Si l'utisateur sue le bouton recherhe ce derneir change de forme 
let searchbtn = document.querySelector('#search-btn'); 
let searchbar = document.querySelector('.search-bar-container');

let menu= document.querySelector("#menu-bar");
let menuBar = document.querySelector(".menu-bar")
// Si l'utisateur sue le bouton recherhe ce derneir change de forme 
window.scroll = () =>{
    searchbtn.classList.remove('fa-times');   
    searchbar.classList.remove('active');
    menu.classList.remove('fa-times'); // la forme change au clique du bouton  
    menuBar.classList.remove('active')
    
}
searchbtn.addEventListener('click',  () =>{
    searchbtn.classList.toggle('fa-times'); // la forme change au clique du bouton  
    searchbar.classList.toggle('active');
});



//Pour les smart phones l'utilisateur clic sur l'icones 


menu.addEventListener('click',  () =>{
    menu.classList.toggle('fa-times'); // la forme change au clique du bouton  
    menuBar.classList.toggle('active');
});