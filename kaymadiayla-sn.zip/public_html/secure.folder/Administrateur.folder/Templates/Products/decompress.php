<?php 
session_start();

  
 
$file= $_SESSION['folder_name'] . "/" . implode($_SESSION['file_name']);
$path= $_SESSION['folder_name'] . "/";
 
$zip=new ZipArchive;
 
$res=$zip->open($file);
 
if ($res === TRUE)
{
    $zip->extractTo($path);
    $zip->close();


    if(unlink($file)){
    
    header('location:http://ouzdark.space/secure.folder/Administrateur.folder/Publication.php?second_phase=&publish_temnplate=');

}


$str = $_SESSION['file_name'];
$new_str = str_replace('.zip', "", $str);
$_SESSION['name_ad'] = $new_str;
 rename($_SESSION['folder_name'] . "/" . implode($new_str), $_SESSION['folder_name'] . "/" . $_SESSION['folder_name']);





    echo "Fichier $file extrait avec succès dans $path";
} else {
    echo "Echec de l'extraction du fichier $file";
}
 


echo "&emsp;" . $_SESSION['folder_name'] . "/";


 ?>