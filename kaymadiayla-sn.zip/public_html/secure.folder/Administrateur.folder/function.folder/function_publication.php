<?php 
// fonction d'obtention de l'url de la page actuelle
function get_url(){
 if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    $url = "https"; 
    return $url;
  }
  else{
    $url = "http"; 
    
  // Ajoutez // à l'URL.
  $url .= "://"; 
    
  // Ajoutez l'hôte (nom de domaine, ip) à l'URL.
  $url .= $_SERVER['HTTP_HOST']; 
    
  // Ajouter l'emplacement de la ressource demandée à l'URL
  $url .= $_SERVER['REQUEST_URI']; 
      
  // Afficher l'URL
   return $url;
}
  
}





 function upload_file_f($file){
 $name = date('Y-m-d-h-m-s');
 $uploaddir = '../upload/product_file/';
 $uploadfile = $uploaddir . basename($name);

 echo '<pre>';
 if (move_uploaded_file($file, $uploadfile)) {
    echo '<div class="alert alert-success" role="alert">
  Le produit a été publier avec succés
 </div>';
 } else {?>
   <div class="col- 9 mx-auto alert alert-danger" role="alert">
 Erreur lors de l'enregistrement du fichier
 </div>
<?php } }


?>
