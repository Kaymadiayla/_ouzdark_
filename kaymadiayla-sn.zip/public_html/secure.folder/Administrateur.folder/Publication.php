<?php session_start(); ?>
<?php $_SESSION['AD'] = True; ?>
<?php require_once("publication_form.php"); ?>
<?php include('base.folder/linkbd.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <title></title>
  <!-- lien font google -->
  <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
  <!-- lien css bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  <!-- lien css local -->
  <!-- lien d'inclusion d'icone bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css.folder/principal.css">
  <?php if(isset($_SESSION['CH'])): ?> <link rel="stylesheet" type="text/css" href="css.folder/index1.css"> <?php endif ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<?php if (isset($_SESSION['AD'])): ?>
 <body class="body" style="font-family: Nunito;">

   <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
     <a class="navbar-brand" href="#">Ouzdark</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
   </button>
   <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
       <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="#">Acceuil</a>
     </li>
    
     <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
         Action
      </a>
      <ul class="dropdown-menu">
         <li><a class="dropdown-item" href="#">Organiser</a></li>
         <li><a class="dropdown-item" href="#">Gerer</a></li>
         
      </ul>
   </li>
   
</ul>
<form class="d-flex" role="search">
 <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
 <button class="btn btn-outline-success" type="submit">Search</button>
</form>
</div>
</div>
</nav>

<div class="container-fluid">
   <div class="mt-3 row col-12">
      <div class="bg-white shadow-sm col-12 col-sm-6 col-md-7 col-lg-5 col-xl-5 mx-3" style="border-radius: 15px; padding: 15px;">
         <div class="fs-6 color-dark-blue">
            Publication:
         </div>
         <div class="mt-3">
            <!-- dropdown -->
            <div class="btn-group">
               <div class="publish_btn">
             <button type="button" class=" bg-pink color-white border-pink btn btn-danger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
              Nouveau produit
           </button>
           <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="http://ouzdark.space/secure.folder/Administrateur.folder/Templates">Templates</a></li>
              <li><a class="dropdown-item" href="http://ouzdark.space/secure.folder/Administrateur.folder/Publication.php?publish_plugin=">Plugins</a></li>
        </ul>
     </div>
              </div>

           <!-- end of the dropdown -->



<!-- 
==================================
PROTOTYPAGE PHP
==================================
 -->

<!-- prototypage php -->
<?php if (isset($_SESSION['CH'])): ?>
   <?php unset($_SESSION['CH']); ?>
<?php endif ?>
<?php if (isset($_GET['publish_temnplate'])): ?>
<?php include('function.folder/function_publication.php'); ?>
   <!-- on annule la vision du bouton de publication avec du javascript -->
   <script>
      let publish_btn = document.querySelector('div.publish_btn');
      publish_btn.innerHTML = ' ';
   </script>
   <!-- fin de l'anulation -->
<!-- <form action="" method="post" enctype="multipart/form-data" class="import_form col-11 mb-3"> 
  <label for="formFileMultiple" class="form-label">Importer le dossier-template</label>
  <input multiple name="template_folder" class="form-control" type="file" id="formFileMultiple" required >
   <button type="submit" class="mt-3 bg-pink border-pink btn btn-primary">Importer</button>

   <br>  
   <br>
   <span style="color: rgba(0, 0, 0, 0.50);">Les fichiers volumineux diminue la durée de vie de votre hebergeur</span>
</form>-->


<?php if (isset($_GET['second_phase'])): ?>


         <!-- Enregistrement des fichiers dans le gestionnaires de fichiers -->

         <?php  

          
?>

         <script>
            let import_form = document.querySelector('form.import_form');
            import_form.innerHTML = '';
         </script>
            
            <form action="<?php echo get_url(); ?>" method="GET" class="import_form_1 col-11 mb-3">
           
           <div class="form-floating">
           <input name="tmpl_name" type="text" class="form-control" id="floatingInputValue" placeholder="Template-name" value="<?php echo $_SESSION['folder_name']; ?>">
           <label for="floatingInputValue">Nom de template</label>
         </div>
         <div class="mt-3 form-floating">
           <input required minlength="3" name="owner_name" type="text" class="form-control" id="floatingInput" placeholder="Nom du createur du template">
           <label for="floatingInput">Auteur</label>
         </div>
         <div class="mt-3 form-floating">
           <input required minlength="3" name="description" type="text" class="form-control" id="floatingInput" placeholder="Description">
           <label for="floatingInput">Description</label>
         </div>
         <select name="categorie" class="mt-3 form-select" aria-label="Default select example">
            <!-- recuperons les options de catégories presents dans la base de donnée -->
            <option value="0" selected> Type de produit</option>
            <?php $recovery = $db->prepare('SELECT * FROM Templates_categories WHERE Valid =? ORDER BY `Categorie` ASC'); ?>
            <?php $recovery->execute(array('1')); ?>
            <?php while($resultat = $recovery->fetch()){ ?>
           <option value="<?php echo $resultat['Categorie']; ?>"><?php echo $resultat['Categorie']; ?></option>
         <?php } ?>
           
         </select>

         <select name="statut" class="mt-3 form-select" aria-label="Default select example">
            <option value="0">Payant ou gratuit ?</option>
           <option value="Payant">Gratuit</option>
           <option value="Gratuit">Payant</option>
         </select>
            <button name="import" type="submit" class="mt-3 bg-pink border-pink btn btn-primary">Importer</button>

            <br>  
            <br>
            <span style="color: rgba(0, 0, 0, 0.50);">Les fichiers volumineux diminue la durée de vie de votre hebergeur</span>
         </form>
            



<?php endif ?>

<?php endif ?>
<!-- traitement final du fichier -->

<?php if (isset($_GET['import'])): ?>
   <?php if ($_GET['categorie'] != '0'): ?>
      <?php if ($_GET['statut'] != '0'): ?>



  
        <?php
 


if(rename("Templates/Products/". $_SESSION['folder_name'], "Templates/Products/". $_GET['tmpl_name'])):?>
  
   
<?php $_SESSION['folder_name'] = $_GET['tmpl_name']; ?>

   



  <!-- enregistrement des informations dans la base de donnée -->
<?php $requette = "INSERT INTO Templates_A(Description, Auteur, Statut, Type, Template_folder) VALUES (?, ?, ?, ?, ?) "; ?>

<?php $insert = $db->prepare($requette); ?>
<?php $requette_execution =  $insert->execute(array($_GET['description'], $_GET['owner_name'], $_GET['statut'], $_GET['categorie'], $_SESSION['folder_name'])); ?>
<?php if ($requette_execution): ?>
   <script>
      alert('Requette executée avec succés');
      document.location.href = 'http://ouzdark.space/secure.folder/Administrateur.folder/Publication.php';
   </script>
<?php else: ?>
   <script>
      alert('Une erreur est survenu lors de l\'execution de la requette');
   </script>
<?php endif ?>



<script>
   alert('Les informations ont été mis a jour avec succés');
   document.location.href = 'http://ouzdark.space/secure.folder/Administrateur.folder/Publication.php?';
</script>







<?php else: ?>
<script>
   alert('Une erreur est survenue lors du traitement des informations');
</script>

<?php endif ?>;

     



      <?php else: ?>
         <script>
            alert('Veuiller definir un statut pour ce produit');
         </script>
   <?php endif ?>
      <?php else: ?>
         <script>
            alert('Veuiller definir une categorie pour ce produit');
         </script>
   <?php endif ?>
<?php endif ?>

 <!-- 
===============================
FIN DU PROTOTYPAGE
===============================
  -->







        </div>

     </div>
     <div class="bg-white shadow-sm col-12 col-sm-4 col-md-5 col-lg-4 col-xl-4 mx-3 mt-3" style="border-radius: 15px; padding: 15px;">
ejhfehf
     </div>
     <div class=" mt-3 bg-white shadow-sm col-12 col-sm-7 col-md-6 col-lg-1 col-xl-2 mx-3" style="border-radius: 15px; padding: 15px;">

     </div>
  </div>


</div>










<!-- lien javascript boostrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="javascript.folder/index.js" defer ></script>

</body>
<?php else: ?>
   <div class="mt-5 text-center mx-auto alert alert-danger col-10 col-sm-7 col-md-7 col-lg-5 col-xl-5" role="alert">
    Acces denied
 </div>
<?php endif ?>
</html>
<script type="text/javascript">
   let body = document.querySelector('body.body');
   setTimeout(function(){
      body.style.transitionDuration = '2s';
      body.style.background = '#f3f3f3';
   }, 500)
</script>


