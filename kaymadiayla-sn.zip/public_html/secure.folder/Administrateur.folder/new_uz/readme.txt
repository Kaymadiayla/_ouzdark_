Synth�se vocale---------------
Url     : http://codes-sources.commentcamarche.net/source/42235-synthese-vocaleAuteur  : stfouDate    : 24/08/2013
Licence :
=========

Ce document intitul� � Synth�se vocale � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Synth&egrave;se vocale : je n'ai pas fait de synth&egrave;se vocale ! non non. j
e ne fait qu'utiliser la synth&egrave;se de microsoft en fran&ccedil;ais. pour l
a t&eacute;l&eacute;charger :
<br />
<br /><a href='http://download.microsoft.
com/download/msreader/utility/1.0/w98nt42kmexp/fr/ReaderTTSInstallFRA.exe' targe
t='_blank'>http://download.microsoft.com/download/msreader/utility/1.0/w98nt42km
exp/fr/ReaderTTSInstallFRA.exe</a>
<br />
<br />Donc, &ccedil;a fait un esp&eg
rave;ce de narrateur en fran&ccedil;ais.
<br />On peut lire :
<br />-Le texte 
selectionn&eacute; (on selectionne le texte, on fait clic droit et &ccedil;a lit
).
<br />-Le texte entr&eacute; dans la zone de texte.
<br />-Les touches entr
&eacute;es au clavier.
<br /><a name='source-exemple'></a><h2> Source / Exemple
 : </h2>
<br /><pre class='code' data-mode='basic'>
[Z]ozo
[I]dentifiant
[P
]rotocol

//Attention ! si vous ne t�l�chargez pas la voix fran�aise, ce sera 
la voix anglaise qui vous parlera, horreur garantie.
</pre>
<br /><a name='con
clusion'></a><h2> Conclusion : </h2>
<br />Suggestions ?
