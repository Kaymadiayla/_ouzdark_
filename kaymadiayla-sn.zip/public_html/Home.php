<?php include('secure.folder/Administrateur.folder/base.folder/linkbd.php'); ?>
<!DOCTYPE html>
<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Ouzdark</title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css.folder/Home1.css">
<link rel="stylesheet" type="text/css" href="css.folder/principal.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>
<body class="element" style="overflow-x: hidden; font-family: Nunito;">



<?php if (!isset($_GET['Products'])): ?>
  



<!-- 
============================
MENU
============================
-->
<nav class="navbar shadow-sm navbar-expand-lg bg-pink">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Ouzdark</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="color-white navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
       
        <li class="nav-item">
          <a class="nav-link" href="#">Mes produits</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Templates
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Gratuit</a></li>
            <li><a class="dropdown-item" href="#">Public</a></li>
            <li><a class="dropdown-item" href="#">Personnel</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled">Plugins</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Categories(Templates, Plugins...) " aria-label="Search">
        <button class="btn border-dark-blue bg-dark-blue color-white" type="submit">Rechercher</button>
      </form>
    </div>
  </div>
</nav>
<!-- 
============================
FIN DE MENU
============================
-->

	<button class="shadow-sm more-button btn bg-dark-blue" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><i class="color-white bi bi-three-dots-vertical"></i></button>

<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel">Options</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <ul class="list-group">
  <li class="list-group-item"><i class="bi bi-person"></i> Mon compte</li>
  <li class="list-group-item"><i class="bi bi-cloud"></i> Sauvegarde</li>
  <li class="list-group-item"><i class="bi bi-gear"></i> Paramétres</li>
  <li class="list-group-item"><i class="bi bi-headset"></i> Service clients</li>
  <li class="list-group-item"><i class="bi bi-chat-square-quote"></i> Parler en public</li>
</ul>
  </div>
</div>



<!-- 
+====================================
AVANT PREMIERE ZONE
=====================================
  -->
  <div style="background: url('http://ouzdark.space/media/images/background-header.jpeg'); background-size: cover; background-repeat: no-repeat;" class="container-fluid">
<div style=" border-top-left-radius: 15px; border-top-right-radius: 15px; margin: 0 auto; padding: 0 60px;  height: 300px; background: rgba(0, 0, 0, 0.50); text-align: center;" class="before-first-place-0 container-fluid col-12 shadow-sm ">

  <div style=" transition-duration: 2s; " class="mx-auto col-12 col-sm-7 col-md-6 col-lg-3 col-xl-4">
    <div>
      &emsp;
    </div>
    <div class="col-12">
    <img width="100%" src="http://ouzdark.space/media/images/center1.webp">
    <!-- <img src="http://ouzdark.space/media/images/center-img.webp"> -->
    
    </div>
   
  </div>
 <div class="col-12 col-lg-7">
      
    </div>

</div>
</div>
<!-- 
+====================================
FIN AVANT PREMIERE ZONE
=====================================
  -->

 





<!-- 
+====================================
PREMIERE ZONE
=====================================
  -->

<div class="first-place">
  <div style="padding: 0 0; background: url('https://img.freepik.com/premium-psd/floating-website-template-design-mockup_513308-55.jpg'); background-size: 100%; background-repeat: no-repeat;" class="col-6 col-sm-4 col-md-4 col-lg-3 col-xl-3 col-xxl-2 d-flex categorie shadow-sm">
	<div style="border-radius: 10px; background: rgba(0, 0, 0, 0.7);" class="container">
		<div class="illustration">	
			<i class="illustration_icon bi bi-window-fullscreen"></i>
		</div>
	</div>
</div>
</div>
  <!-- 
+====================================
FIN DE LA PREMIERE ZONE
=====================================
  -->

<!-- Deuxieme zone -->

<style>
  .element::-webkit-scrollbar { width: 0 !important }
</style>

<div class="" style="margin-left: 10px; margin-bottom: 15px;">
  Templates :
</div>
<div class="element container-fluid d-flex" style=" margin-bottom: 15px; overflow-x: auto; overflow-y: hidden; max-height: 250px;  padding-bottom: 10px;">

<!-- recuperation des templates -->
<?php $recovery = $db->prepare('SELECT * FROM Templates_A WHERE Disponible = ?'); ?>
<?php $recovery->execute(array('1')); ?>

<?php while($resultat = $recovery->fetch()) { ?>
  <div style="padding: 10px; margin-right: 15px; border-radius: 10px;" class="col-5 col-sm-4 col-md-3 col-lg-3 col-xl-2 bg-white shadow-sm" >

    <div class="row">
  <div class="col-8 text-truncate">
    <strong style="font-size: 14px;"><?php echo $resultat['Template_folder']; ?></strong>
  </div>
  <a class="col-3"  data-bs-toggle="modal" data-bs-target="#<?php echo $resultat['Template_folder']; ?>">
    <i  color="#625F8C" class="fs-3 bi bi-eye"></i>
  </a>
  <img style="border-radius:10px;" src="http://ouzdark.space/secure.folder/Administrateur.folder/Templates/Products/<?php echo $resultat['Template_folder']; ?>/aperçu.png" alt="">
  <div class="mt-2 btn-group" role="group" aria-label="Basic outlined example">
    <?php $id = $resultat['ID']; ?>
  <button type="button" onclick="document.location.href = 'http://ouzdark.space/Home.php?Products=<?php echo $id; ?>'" class="btn btn-outline-primary">Voir</button>
  <button type="button" class="btn btn-outline-primary"><i class="bi bi-download"></i></button>
</div>

</div>
    
  </div>



  <div class="modal fade" id="<?php echo $resultat['Template_folder']; ?>" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalToggleLabel"><?php echo $resultat['Template_folder']; ?></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

       <?php 
       $folder = $resultat['Template_folder'];
        $files = glob("secure.folder/Administrateur.folder/Templates/Products/$folder/*.*");/* $files pour "lister" les fichiers - Mise en place de *.* pour dire que ce dossier contient une extension (par exemple .jpg, .php, etc... */
$compteur = count($files);

        ?>

       <img width="100%"  style=" border-radius:10px;" src="http://ouzdark.space/secure.folder/Administrateur.folder/Templates/Products/<?php echo $resultat['Template_folder']; ?>/aperçu.png" alt="">
      </div>
      <div class="modal-footer">
        <button onclick class="btn btn-primary" >Tester</button>
      </div>
    </div>
  </div>
</div>

<?php } ?>

</div>


<!-- Fin deuxieme zone -->



<!-- Deuxieme zone -->
<div style="background: url('http://ouzdark.space/media/images/design.jpeg'); padding:0;" class="mt-1 container-fluid row">
  <div class="container-fluid row" style=" width: 150% !important; background: rgba(0, 0, 0, 0.30); margin:0 0;">
  <div class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 mt-1">
    
  </div>

  <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 mt-1">
      <center>
    <div style="border-radius: 10px; padding: 20px 10px;" class="row cont-2 mb-2 bg-white shadow-sm col-12">
      
  
      <div style="text-align: left; margin-left: 15px; color: #625F8C; float-right" class="element my-auto col-6">
        <strong style="">
          Avez vous des idées en digital ?  <br>Qu'attendez vous pour les realiser ? Nous vous rappelons que nous pouvons tout faire á votre place .
        </strong>
        <br>
        <button data-bs-toggle="modal" data-bs-target="#<?php echo $resultat['ID']; ?>" class="btn-command mt-2 btn" style="color: white; background: #f14a69;">Commander</button>
      </div>
       <div class="col-5 my-auto" >
        <img width="70%" src="http://ouzdark.space/media/images/command-prototype.png" alt="">
      </div>


    </div>
    <!-- Scrollable modal -->

    </center>
    <center>
    <div style="text-align: left; border-radius: 10px; padding: 20px 10px;" class="element cont-1 float-right mb-2 bg-white shadow-sm col-12 row">
      <div class="col-5 my-auto" >
        <img width="70%" src="http://ouzdark.space/media/images/command-design.png" alt="">
      </div>
      <div style="color: #625F8C; float-right" class="my-auto col-6">
        <strong>
          Commander des templates bien designé et personnalisé
        </strong>
        <br>
        <button class="btn-command mt-2 btn" style="color: white; background: #625F8C;">Commander</button>
      </div>
    </div>
</center>
  </div>
</div>
</div>
<!-- Fin deuxieme zone -->

<style>
  .cont-1{
    background: rgb(255,255,255);
background: linear-gradient(11deg, rgba(255,255,255,1) 67%, rgba(241,74,105,0.7441351540616247) 100%);
}
.cont-2{
background: rgb(98,95,140);
background: linear-gradient(12deg, rgba(98,95,140,1) 0%, rgba(255,255,255,1) 31%, rgba(255,255,255,1) 33%, rgba(255,255,255,1) 49%);
}

.btn-command{
  transition: 1s;
}
.btn-command:hover{
  transform: scale(1.1);
  transition: 1s;
}

.bi-eye:hover{
  cursor: pointer;
}
</style>










<?php endif ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  
</body>
</html>

<style type="text/css">
  @media screen 
  and (max-device-width: 991px) 
{

.before-first-z{
 visibility: hidden;
 background: red;
}
}
</style>