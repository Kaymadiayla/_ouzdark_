<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Ouzdark</title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <link rel="stylesheet" type="text/css" href="css.folder/index55.css">
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>
  <body style="font-family: Nunito;">
   


<div class="mt-2 container-fluid principal-container">
  

<!-- 
======================================
MENU DU HAUT
======================================
 -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand logo" href="#"><strong>Ouzdark</strong></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul style="font-family: Nunito;" class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Accueil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Sites</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled">Plugins</a>
        </li>
      </ul>
      <form class="d-flex" role="Rechercher">
        <input class="form-control me-2" type="search" placeholder="Rechercher" aria-label="Rechercher">
        <button class="btn btn-search" type="submit">Rechercher</button>
      </form>
    </div>
  </div>
</nav>
<!-- 
======================================
FIN DU MENU DU HAUT
======================================
 -->


<div class="mt-5 container-fluid">
  <div class="row">
     <div class="div_text shadow-sm col-12 bienvenue col-sm-11 mx-sm-auto col-md-6 col-lg-6" style="margin-right: 70px;margin-top: 40px;">
     <span class="fs-3 owner-full-name"><span class="owner-first-name">Ousmane ndoye</span></span> <span class="fs-3"> vous salut <i class="fs-1 bi bi-stars"></i> !</span>
    <br>
     <br>
    <span class="bienvenue fs-6">Au cours de ces derniéres années, j'ai su batir une excellente reputation en matiére de vente, d'achat, de gain de temps et d'efficacité.
          <br>
    Toutes fois aprés inscription vous aurez la possibilité de commander des application web, des plugins de qualités et autres?
    <br>
    <a style="text-decoration: none;" class="fs-6" href="">En savoir plus...</a>
     </span>
     <br>
     <button onclick="document.location.href='pages/public_html/connexion.php?back=http://ouzdark.space'" class="shadow-sm btn1">Se connecter</button>&emsp;<button class="shadow-sm btn2" onclick="document.location.href='pages/public_html/inscription.php'" >S'inscrire</button>
     <br>
    

  </div>
  <div class="image informatic-illustration col-12 col-sm-11 mx-sm-auto col-md-6 col-lg-5" style="margin-top: 40px;">
    <img style="width:100%; height: auto;" src="media/images/informatique.png">
  </div>
  </div>
 
</div>


  <div style="" class="mt-5 container-fluid">
    <br>
    <strong><h4 style="color: #625F8C; font-weight: 800;">Nouveautés:</h4></strong>
    <span style="font-size: 12px;">
      Une fois qu'une nouvelle fonctionnalités est ajoutés au plate-forme, nous les annoncerons en mp3 (audio) qui seront affiché juste la devant vous
    </span>
    <hr>
    <br>
    
    <br>
  <div class="col-7 col-md-5 col-sm-5 col-lg-4 col-xl-4 col-xxl-3 cicle">
    <audio controls class="publicity1"></audio>
        <audio controls class="publicity2"></audio>
            <audio controls class="publicity3"></audio>
  </div>
</div>
<br>
<hr>
<br>
 <strong><h4 class="mt-5" style="color: #625F8C; font-weight: 800;">Services:</h4></strong>
<br>
<div class="div-deco mt-1 container-fluid">
  
<div style="text-align: center;" align="center" class="row mt-5">
 
  <div class="div1 col-11 col-sm-5 col-md-5 col-lg-3 object1">
    <span>
    <i class="bi bi-window-stack"></i>
    <br>
    <span class="fs-6"><strong style="font-weight: 600; color: #625F8C ;">Creer votre site web avec nos modéles</strong></span>
    </span>
    <br>
    <br>
    <span style="font-size: 15px;">
      Créez un site Web gratuit sans aucune compétence technique requise et donnez vie à votre vision. Avec la configuration gratuite du site Web, vous pouvez lancer un site professionnel et personnalisé en quelques heures.
    </span>
      <br>
   
      <a href="" type="button" class="" data-bs-toggle="modal" data-bs-target="#contactservice">Contacter le service client </a>
      <br>

     <button style="opacity: 50%;" class="btn bty view mt-3 col-11 mx-auto">Non diponible</button>
      
 <style type="text/css">
   .bty:hover{
    background: #625F8C;
    opacity: 50%;
   transform: none;
   color: white;
   }
 </style>
  </div> 



  <div class="div2 col-11 col-sm-5 col-md-5 col-lg-3 object2">
    <span style="font-size: 15px;">
      <i class="bi bi-code-slash"></i>
  <br>
   <span class="fs-6"><strong style="font-weight: 600; color: #625F8C ;">Je veux un plugin</strong></span>
    </span>
    </span>
    <br>
    <br>
     <span style="font-size: 15px;">
      Il est diponible sur notre plateforme, des plugins de trés bonnes qualités.
      Ces derniers vous faciliterons le travail et reduirons son temps.
      <br>
      Exemples (formulaire php avec base de donnée, systémes de messageries... )
      .
   <br>
   <br>
      <a href="" type="button" class="" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Qu'est ce qu'un plugin ?</a>
     </span>
      <button class="btn view mt-3 col-11 mx-auto">Voir</button>
  </div>  
  <div class="div3 col-11 col-sm-5 col-md-5 col-lg-3 object3">
    <span>
   <i class="bi bi-globe2"></i>
       <br>
    <span class="fs-6"><strong style="font-weight: 600; color: #625F8C ;">Je veux un site Web</strong></span>

    <br>
    <br>
    <span style="font-size: 15px;">
      Nous vous rappelons qu'il existe des sites Web deja créée et prêts á l'emploi, si vous ne les aimés pas, alors vous pouvez en commander un dans la dans la page de vente que vous pouvez acceder grace au boutton ci-contre.
      <br>
     
    </span>
    </span>
    <br>
     <a href="" type="button" class="" data-bs-toggle="modal" data-bs-target="#ineverhavewebsite">Je n'ai jamais eu de site web </a>
      <br>
    <button class="btn view mt-3 mb-2 col-11 mx-auto">Voir</button>
     <span style="font-size: 12px; color:#f14a69;">
        Afin d'eviter les similarités, un site Web deja vendu, n'est plus vendable (seul le proprietaire peut le vendre á nouveau);
      </span>
  </div>

</div>


</div>
 
<div class="day-info container-fluid">
  
</div>



</div>








<!-- Modal definition plugin -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Qu'est ce qu'un plugin</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Le plugin, également appelé module d'extension, add-in ou add-on, est un programme additionnel pour une application internet ou un logiciel de bureau. Développé en cohérence avec un programme principal, il lui offre de nouvelles fonctionnalités sans modifier son code source.
      </div>
      <div class="modal-footer">
       
       <div class="text-center bg-white container-fluid">
  Contacter par whatsApp
  <br>
  <img style="cursor: pointer; " onclick="document.location.href='https://wa.me/+221751081100?text=Bonjour, j\'envoie ce message pour verifier votre disponibilité afin de vous poser quelques questions a propos de votre site web ouzdark.space '" width="40px" height="40px" src="media/images/icone_whatsApp.gif">
  

</div>
      </div>
    </div>
  </div>
</div>




<!-- Modal definition plugin -->
<div class="modal fade" id="contactservice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Qu'est ce qu'un plugin</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       En préferences, le service client est disponible:
       <br>
       Tous les jours :
       <br>
       de :
       <br>
       13h á 14h:30 ;<br>19h á 22h:00 ; <br>7h á 7hh:30 ; <br>

      </div>
      <div class="modal-footer">
       
         <div class="text-center bg-white container-fluid">
  Contacter par whatsApp
  <br>
  <img style="cursor: pointer; " onclick="document.location.href='https://wa.me/+221751081100?text=Bonjour, j\'envoie ce message pour verifier votre disponibilité afin de vous poser quelques questions a propos de votre site web ouzdark.space '" width="40px" height="40px" src="media/images/icone_whatsApp.gif">


</div>
      </div>
    </div>
  </div>
</div>

<!-- Modal definition plugin -->
<div class="modal fade" id="ineverhavewebsite" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Comprendre un site web</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Vous n'avez jamais eu de site internet de votre vie, vous souhaiteriez peut étre le comprendre avant de vous lancer. <br>
        Pour cela nous vous conseillons de nous contacter par whatsApp, nous repondrons a toutes vos questions en seulement moins de 2 minutes.
        Si vous êtes pressés, sachez qu'un site intenet fonctionne exactement comme instagram par exemple.
        La gestion d'un site web se fait de la méme maniére que de celui d'un compte tik-tok, comme instagram
      </div>
      <div class="modal-footer">
       
         <div class="text-center bg-white container-fluid">
  Contacter par whatsApp
  <br>
  <img style="cursor: pointer; " onclick="document.location.href='https://wa.me/+221751081100?text=Bonjour, j\'envoie ce message pour verifier votre disponibilité afin de vous poser quelques questions a propos de votre site web ouzdark.space '" width="40px" height="40px" src="media/images/icone_whatsApp.gif">
 

</div>
      </div>
    </div>
  </div>
</div>
<div class="text-center bg-white container-fluid">
  Contacter par whatsApp
  <br>
  <img style="cursor: pointer; " onclick="document.location.href='https://wa.me/+221751081100?text=Bonjour, j\'envoie ce message pour verifier votre disponibilité afin de vous poser quelques questions a propos de votre site web ouzdark.space '" width="40px" height="40px" src="media/images/icone_whatsApp.gif">
  <br>
  <br>
  <br>
   <h6 style="color: gray;">Create by: Ousmane Ndoye</h6>
  <h6 style="color: gray;">Copyright © 2022</h6>

</div>
<script> 

 
   var div_img = document.querySelector('div.image'); 
   var div_text = document.querySelector('div.div_text');
   var div1 = document.querySelector('div.div1');
   var div2 = document.querySelector('div.div2');
   var div3 = document.querySelector('div.div3');
   div_img.style.transform = 'translateX(800px)';    
   div_text.style.transform = 'translateX(-800px)';
   div_text.style.transitionDuration = '1.3s';
   div1.style.transform = 'translateY(200px)';
   div1.style.transitionDuration = '2s';
   div2.style.transform = 'translateY(400px)';
   div2.style.transitionDuration = '2s';
   div3.style.transform = 'translateY(600px)';
   div3.style.transitionDuration = '2s';
   setTimeout(function(){
    div_text.style.transitionDuration = '1.3s';
    div_text.style.transform = 'translateX(0)';
     setTimeout(function(){
    div_img.style.transitionDuration = '1.3s';
    div_img.style.transform = 'translateX(0)';

 setTimeout(function(){
    div1.style.transitionDuration = '1.3s';
    div1.style.transform = 'translateY(0)';
     setTimeout(function(){
    div2.style.transitionDuration = '1.3s';
    div2.style.transform = 'translateY(0)';

     setTimeout(function(){
    div3.style.transitionDuration = '1.3s';
    div3.style.transform = 'translateY(0)';
   },500) 
   },500)   

   },500) 



   });}); 


</script> 




   <!-- lien javascript boostrap -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  </body>
</html>