<?php session_start(); ?> 
<?php include('base.folder/linkbd.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title></title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css.folder/index1.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  </head>
  <body style="background: black; font: 14px SFMono-Regular, Menlo, Monaco;">

<div class="container-fluid mt-3">
  <div class="mx-auto col-7">
    <div class="form-floating mb-3 col-12 d-flex">
  <input style="filter: brightness(3); color: rgba(34, 266, 7, 1.0); border-radius: 15px; border: 2px solid rgba(34, 266, 7, 1.0); background: transparent;" type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label style="color: rgba(34, 266, 7, 1.0);" for="floatingInput">Email address</label>
  <!-- Example single danger button -->
  <div class="">
    &ensp;
  </div>
<div class="btn-group ml-2">
  <button style="background: transparent; border: 2px solid rgba(34, 266, 7, 1.0); border-radius: 15px;" type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
    Act
  </button>
  <ul style="background: transparent; border: 2px solid rgba(34, 266, 7, 1.0);" class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
    <li><hr class="dropdown-divider"></li>
    <li><a class="dropdown-item" href="#">Separated link</a></li>
  </ul>
</div>

</div>
  </div>
</div>

<!-- horizontal -->
 <?php if (isset($_GET['ID'])): ?>
   
 <!-- on pars chercher les info de l'elements -->
<?php $go_fetchi = $db->prepare('SELECT * FROM Elements WHERE ID = ? LIMIT 1'); ?>
<?php $go_fetchi->execute(array(trim($_GET['ID']))); ?>
<?php $fetched_number = $go_fetchi->rowCount(); ?>

<?php if($fetched_number > 0): ?>
  <?php while($go_fetch = $go_fetchi->fetch()){ ?>
<div class="container-fluid d-flex">
 
<div class="animate-text col-4" style="text-align: left; color: rgba(34, 266, 7, 1.0); max-width: 30%; max-height: 350px;">
  Ousmane ndoye. 
  <br>
  <br>
  A etudier a l'ecole <span style="text-shadow: 0, -2px rgba(34, 266, 7, 1); filter: brightness(5);">grande royal depuis 2012</span>, il y fut sa classe de cp pour y quitter aprés obtention de son cfe en 2017. Puis partis au cem de capec pour y faire a classe de 6eme, perturbée par des problémes de famille, il quitta dakar aprés son année scolaire pour migrer vers ziguinchor ou il ne fera que 1 ans, puis revenu a dakar, il etudia a pape benoit pour une durée de 3ans, et termina ces etudes a ep collegial de la cité sonatel, de la zac de mbao
</div>

<div class="flip">
    <div class="front" style="text-align: left; border: 2px solid rgba(34, 266, 7, 1.0); background: black; box-shadow: 0 0 70px 5px rgba(255, 255, 255, 0.20);">
      <div class="">
        <span class="">
          
       
        <i style="font-size: 70px; color: rgba(34, 266, 7, 1.0);" class="bi bi-person-check"></i>





         </span>
        <span class="w-25" style="margin-top: -15px; float: right; height: 100px; ">
  <?php   include('qr.php'); ?>
</span>
         
         <table style=" color:rgba(34, 266, 7, 1.0);">
           <tr>
             <td>
               Prenom:
             </td>
             <td>
               <?php echo $go_fetch['Prenom']; ?>
             </td>
           </tr>
           <tr>
             <td>
               Nom:
             </td>
             <td>
              <?php echo $go_fetch['Nom']; ?>
             </td>
             </tr>
             <tr>
             <td>
               Naissance:&ensp;
             </td>
             <td>
              <?php echo $go_fetch['Date_de_naissance']; ?>
             </td>
           </tr>

           <tr>
             <td>
               Sexe:
             </td>
             <td>
               <?php echo $go_fetch['Sexe']; ?>
             </td>
           </tr> <tr>
             <td>
               Statut:
             </td>
             <td>
              <?php echo $go_fetch['Statut']; ?>
             </td>
           </tr>
         </table>
      </div>
    </div>
    <div style="text-align: left; border: 2px solid rgba(34, 266, 7, 1.0); background: black; box-shadow: 0 0 70px 5px rgba(255, 255, 255, 0.20);" class="back">
        <table style=" color:rgba(34, 266, 7, 1.0);">
           <tr>
             <td>
               ID:
             </td>
             <td>
               <?php echo $go_fetch['ID']; ?>
             </td>
           </tr>
           <tr>
             <td>
               Telephone:
             </td>
             <td>
              <?php echo $go_fetch['Telephone']; ?>
             </td>
           </tr>
           <tr>
             <td>
               ID-familliale:&ensp;
             </td>
             <td>
               <?php echo $go_fetch['id_de_famille']; ?>
             </td>
           </tr>
           <tr>
             <td>
               Email:
             </td>
             <td>
               <?php echo $go_fetch['Email']; ?>
             </td>
             </tr>
             <tr>
             <td>
               Adresse:&ensp;
             </td>
             <td>
               <?php echo $go_fetch['Adresse']; ?>
             </td>
           </tr><tr>
             <td>
               Adresse-map:&ensp;
             </td>
             <td>
               <?php echo $go_fetch['Adresse map']; ?>
             </td>
           </tr>

           <tr>
             <td>
               Profession:
             </td>
             <td>
<?php echo $go_fetch['Profession']; ?>
             </td>
           </tr> 
         </table>
    </div>
</div>

</div>
<?php } ?>
<?php else: ?>
  <script type="text/javascript">
    alert("L'element est introuvable");
  </script>
<?php endif ?>
 <!-- <?php endif ?>   si la variable get est definis fin----->
<div class="container-fluid mt-5">
  <div style="float: left; margin-bottom: 15px; margin-left: -10px;">
    <strong>
      <span style="color: rgba(34, 266, 7, 1.0);">
             Male
            </span>
    </strong>
  </div>

  <div class="overflow-x: auto; overflow-y: hidden; container-fluid first-p d-flex">


    <!-- rewcuperations des element male -->
    <?php $recovery = $db->prepare('SELECT * FROM Elements WHERE Sexe = ?'); ?>
    <?php $recovery->execute(array('Masculin')); ?>
    <?php while($recov = $recovery->fetch()){ ?>
       <div onclick="document.location.href = 'http://ouzdark.space/other.folder/espion.folder/data.folder/?ID=<?php echo $recov['ID']; ?>'" style="text-align: left; box-shadow: 0 0 20px 5px rgba(34, 266, 7, 0.2); border-radius: 15px; margin: 0 10px; " class="col-4 col-sm-4 col-md-4 col-xl-2 col-xxl-2">
      <i style="font-size: 70px; color: rgba(34, 266, 7, 1.0);" class="bi bi-person"></i>
      <i style="font-weight: 800; color: rgba(112, 236, 245, 1.0); font-size: 20px;" class="bi bi-gender-male"></i>
      <div style="margin-left: 10px; margin-bottom: 20px;">
        <table class="ml-2">
          <tr>
            <td style="color: rgba(34, 266, 7, 1.0);">
              <?php echo $recov['Prenom'].' '.$recov['Nom']; ?>
            </td>
          </tr>
          <tr>
             <td style="margin-top: 10px;  color: rgba(34, 266, 7, 1.0);">
              Include in <?php echo $recov['id_de_famille'] ?>
            </td>
          </tr>
        </table>
      </div>
   
    </div>
  <?php } ?>
  </div> 

  <div style="margin-top: 10px; border-top: 2px solid rgba(34, 266, 7, 1.0); width: 100%;">
    &ensp;
  </div>
 <div style="margin-bottom: 10px; float: left; margin-left: -10px;">
    <strong>
      <span style="color: rgba(34, 266, 7, 1.0);">
             Female
            </span>
    </strong>
  </div>
  <div style="overflow-x: auto; overflow-y: hidden;" class=" mt-4 container-fluid first-p d-flex">
 
<!-- rewcuperations des element female -->
    <?php $recovery = $db->prepare('SELECT * FROM Elements WHERE Sexe = ?'); ?>
    <?php $recovery->execute(array('Feminin')); ?>
    <?php while($recov = $recovery->fetch()){ ?>

      <div onclick="document.location.href = 'http://ouzdark.space/other.folder/espion.folder/data.folder/?ID=<?php echo $recov['ID']; ?>'" style=" text-align: left;box-shadow: 0 0 20px 5px rgba(34, 266, 7, 0.2); border-radius: 15px; margin: 0 10px; " class="col-4 col-sm-4 col-md-4 col-xl-2 col-xxl-2">
      <i style="font-size: 70px; color: rgba(34, 266, 7, 1.0);" class="bi bi-person"></i>
      <i style="font-weight: 800; color: pink; font-size: 20px;" class="bi bi-gender-female"></i>
       <div style="margin-left: 10px; margin-bottom: 20px;">
        <table class="ml-2">
          <tr>
            <td style="color: rgba(34, 266, 7, 1.0);">
              <?php echo $recov['Prenom'].' '.$recov['Nom']; ?>
            </td>
          </tr>
          <tr>
             <td style="margin-top: 10px;  color: rgba(34, 266, 7, 1.0);">
              Include in <?php echo $recov['id_de_famille'] ?>
            </td>
          </tr>
        </table>
      </div>
   
    </div>

  <?php } ?>
  </div>
</div>



<style type="text/css">

.animate-text{
    color: #fff;
      text-shadow:  0 0 7px #fff, 
               0 0 10px #fff, 
               0 0 42px rgb(34, 266, 7),   
               0 0 77px rgb(34, 266, 7), 
               0 0 100px rgb(34, 266, 7) 
}

  .dropdown-item{
    color: rgba(34, 266, 7, 1.0);
    background: transparent;
  }

@import url("https://fonts.googleapis.com/css?family=Roboto+Mono");
* {
  box-sizing: border-box;
  font-weight: normal;
}

body {
  color: #555;
  background: #222;
  text-align: center;
  font-family: "Roboto Mono";
  padding: 1em;
}

h1 {
  font-size: 2.2em;
}

.flip {
  position: relative;
}
.flip > .front,
.flip > .back {
  display: block;
  transition-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1.275);
  transition-duration: 0.5s;
  transition-property: transform, opacity;
}
.flip > .front {
  transform: rotateY(0deg);
}
.flip > .back {
  position: absolute;
  opacity: 0;
  top: 0px;
  left: 0px;
  width: 100%;
  height: 100%;
  transform: rotateY(-180deg);
}
.flip:hover > .front {
  transform: rotateY(180deg);
}
.flip:hover > .back {
  opacity: 1;
  transform: rotateY(0deg);
}
.flip.flip-vertical > .back {
  transform: rotateX(-180deg);
}
.flip.flip-vertical:hover > .front {
  transform: rotateX(180deg);
}
.flip.flip-vertical:hover > .back {
  transform: rotateX(0deg);
}

.flip {
  position: relative;
  display: inline-block;
  margin-right: 2px;
  margin-bottom: 1em;
  width: 400px;
}
.flip > .front,
.flip > .back {
  display: block;
  color: white;
  width: inherit;
  background-size: cover !important;
  background-position: center !important;
  height: 220px;
  padding: 1em 2em;
  background: #313131;
  border-radius: 10px;
}
.flip > .front p,
.flip > .back p {
  font-size: 0.9125rem;
  line-height: 160%;
  color: #999;
}

.text-shadow {
  text-shadow: 1px 1px rgba(0, 0, 0, 0.04), 2px 2px rgba(0, 0, 0, 0.04), 3px 3px rgba(0, 0, 0, 0.04), 4px 4px rgba(0, 0, 0, 0.04), 0.125rem 0.125rem rgba(0, 0, 0, 0.04), 6px 6px rgba(0, 0, 0, 0.04), 7px 7px rgba(0, 0, 0, 0.04), 8px 8px rgba(0, 0, 0, 0.04), 9px 9px rgba(0, 0, 0, 0.04), 0.3125rem 0.3125rem rgba(0, 0, 0, 0.04), 11px 11px rgba(0, 0, 0, 0.04), 12px 12px rgba(0, 0, 0, 0.04), 13px 13px rgba(0, 0, 0, 0.04), 14px 14px rgba(0, 0, 0, 0.04), 0.625rem 0.625rem rgba(0, 0, 0, 0.04), 16px 16px rgba(0, 0, 0, 0.04), 17px 17px rgba(0, 0, 0, 0.04), 18px 18px rgba(0, 0, 0, 0.04), 19px 19px rgba(0, 0, 0, 0.04), 1.25rem 1.25rem rgba(0, 0, 0, 0.04);
}

</style>

 <!-- lien javascript boostrap -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="javascript.folder/index.js" defer ></script>

</body>
</html>


<script type="text/javascript">
  /* ------------------------- */
/* Version en JavaScript pur */
/* ------------------------- */
"use strict";
window.addEventListener("DOMContentLoaded", (event) => {
  animate_text();
});
// -------------------
function animate_text() {
  let delay = 30,
    delay_start = 0,
    contents,
    letters;

  document.querySelectorAll(".animate-text").forEach(function (elem) {
    contents = elem.textContent.trim();
    elem.textContent = "";
    letters = contents.split("");
    elem.style.visibility = "visible";

    letters.forEach(function (letter, index_1) {
      setTimeout(function () {
        // ---------
        // effet machine à écrire (SIMPLE)
        elem.textContent += letter;
        // ---------
        // OU :
        // effet machine à écrire + animation CSS (SPECIAL)
        /*
        var span = document.createElement('span');
        span.innerHTML = letter.replace(/ /,'&nbsp;');
        elem.appendChild(span);
*/
        // ---------
      }, delay_start + delay * index_1);
    });
    delay_start += delay * letters.length;
  });
}

/* ------------------------- */
/* version jQuery */
/* ------------------------- */
/*
"use strict";
$(document).ready(function() {
  animate_text();
});
// -------------------
function animate_text() 
{
  let delay = 100,
      delay_start = 0,
      contents,
      letters;

  $(".animate-text").each(function(index, obj) {
    contents = $(obj).text().trim();
    $(obj).html(''); // on vide le contenu
    letters = contents.split("");
    $(letters).each(function(index_1, letter) {
      setTimeout(function() {
        // ---------
        // effet machine à écrire simple
        $(obj).html( $(obj).html() + letter ); // on ajoute chaque lettre l une après l autre
        // ---------
        // ---------
      }, delay_start + delay * index_1);
    });
    // le suivant démarre à la fin du précédent
    delay_start += delay * letters.length;
  });
}
*/

</script>

