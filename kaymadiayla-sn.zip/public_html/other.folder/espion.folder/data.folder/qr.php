
<title>Cross-Browser QRCode generator for Javascript</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
<script type="text/javascript" src="javascript.folder/jquery.min.js"></script>
<script type="text/javascript" src="javascript.folder/qrcode.js"></script>

<input id="text" type="hidden"  style="width:80%" /><br />
<span id="qrcode" style=""></span>

<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("qrcode"), {
	width : 100,
	height : 100,
	colorDark: "rgba(34, 266, 7)",
colorLight: "black"
});


function makeCode () {		
	var elText = document.getElementById("text");
	elText.value = '<?php if(isset($_GET['ID'])){ $id = $_GET['ID']; echo "http://ouzdark.space/other.folder/espion.folder/data.folder/index.php?ID=$id"; } else{
		echo 'no-value';
	} ?>';
	if (!elText.value) {
		alert("Input a text");
		elText.focus();
		return;
	}
	
	qrcode.makeCode(elText.value);
}

makeCode();

$("#text").
	on("blur", function () {
		makeCode();
	}).
	on("keydown", function (e) {
		if (e.keyCode == 13) {
			makeCode();
		}
	});
</script>
