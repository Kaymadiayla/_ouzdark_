-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mar. 29 nov. 2022 à 12:39
-- Version du serveur :  10.5.16-MariaDB
-- Version de PHP : 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `id19723717_espion`
--

-- --------------------------------------------------------

--
-- Structure de la table `Elements`
--

CREATE TABLE `Elements` (
  `ID` int(11) NOT NULL,
  `Prenom` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Nom` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Date_de_naissance` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Lieu_de_naissance` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Sexe` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Statut` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Telephone` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Email` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Adresse` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Adresse map` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Profession` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Date_derniere_modification` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `Valid` int(1) NOT NULL DEFAULT 1,
  `Date_enregistrement` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `id_de_famille` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini',
  `Histoire` varchar(5000) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Indefini'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Elements`
--

INSERT INTO `Elements` (`ID`, `Prenom`, `Nom`, `Date_de_naissance`, `Lieu_de_naissance`, `Sexe`, `Statut`, `Telephone`, `Email`, `Adresse`, `Adresse map`, `Profession`, `Date_derniere_modification`, `Valid`, `Date_enregistrement`, `id_de_famille`, `Histoire`) VALUES
(1, 'Ousmane', 'Ndoye', '26-11-2004', 'Fatick', 'Masculin', 'Vivant', '+221776633882', 'ousmandoye1234@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'A2', 'Ousmane ndoye. A etudier a l\'ecole grande royal depuis 2012, il y fut sa classe de cp pour y quitter aprés obtention de son cfe en 2017. Puis partis au cem de capec pour y faire a classe de 6eme, perturbée par des problémes de famille, il quitta dakar aprés son année scolaire pour migrer vers ziguinchor ou il ne fera que 1 ans, puis revenu a dakar, il etudia a pape benoit pour une durée de 3ans, et termina ces etudes a ep collegial de la cité sonatel, de la zac de mbao'),
(2, 'Babacar', 'Ndiaye', '26-11-2002', 'Kaolack', 'Masculin', 'Vivant', '+221767456345', 'Babacar@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'A1', 'Babacar  est un garçon qui vit dans le village de Konoah. Il rêve de devenir Hokage (un grand chef qui protège son village et qui est très puissant). Mais il est détesté de tout le monde, car il a un démon scellé en lui: le démon renard à neuf queues (Kyubi)'),
(3, 'Khadijatou', 'Ndoye', '26-11-2004', 'Fatick', 'Feminin', 'Vivant', '+221776633882', 'ousmandoye1234@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'B078', 'Ousmane ndoye. A etudier a l\'ecole grande royal depuis 2012, il y fut sa classe de cp pour y quitter aprés obtention de son cfe en 2017. Puis partis au cem de capec pour y faire a classe de 6eme, perturbée par des problémes de famille, il quitta dakar aprés son année scolaire pour migrer vers ziguinchor ou il ne fera que 1 ans, puis revenu a dakar, il etudia a pape benoit pour une durée de 3ans, et termina ces etudes a ep collegial de la cité sonatel, de la zac de mbao'),
(4, 'Astou', 'Ndiaye', '26-11-2002', 'Kaolack', 'Feminin', 'Vivant', '+221767456345', 'Babacar@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'B34', 'Babacar  est un garçon qui vit dans le village de Konoah. Il rêve de devenir Hokage (un grand chef qui protège son village et qui est très puissant). Mais il est détesté de tout le monde, car il a un démon scellé en lui: le démon renard à neuf queues (Kyubi)'),
(5, 'Mariame', 'Ndong', '26-11-2004', 'Fatick', 'Feminin', 'Vivant', '+221776633882', 'ousmandoye1234@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'A2', 'Ousmane ndoye. A etudier a l\'ecole grande royal depuis 2012, il y fut sa classe de cp pour y quitter aprés obtention de son cfe en 2017. Puis partis au cem de capec pour y faire a classe de 6eme, perturbée par des problémes de famille, il quitta dakar aprés son année scolaire pour migrer vers ziguinchor ou il ne fera que 1 ans, puis revenu a dakar, il etudia a pape benoit pour une durée de 3ans, et termina ces etudes a ep collegial de la cité sonatel, de la zac de mbao'),
(6, 'Fatel', 'sow', '26-11-2002', 'Kaolack', 'Feminin', 'Vivant', '+221767456345', 'Babacar@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'A1', 'Babacar  est un garçon qui vit dans le village de Konoah. Il rêve de devenir Hokage (un grand chef qui protège son village et qui est très puissant). Mais il est détesté de tout le monde, car il a un démon scellé en lui: le démon renard à neuf queues (Kyubi)'),
(7, 'Sirata', 'ba', '26-11-2004', 'Fatick', 'Feminin', 'Vivant', '+221776633882', 'ousmandoye1234@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'B078', 'Ousmane ndoye. A etudier a l\'ecole grande royal depuis 2012, il y fut sa classe de cp pour y quitter aprés obtention de son cfe en 2017. Puis partis au cem de capec pour y faire a classe de 6eme, perturbée par des problémes de famille, il quitta dakar aprés son année scolaire pour migrer vers ziguinchor ou il ne fera que 1 ans, puis revenu a dakar, il etudia a pape benoit pour une durée de 3ans, et termina ces etudes a ep collegial de la cité sonatel, de la zac de mbao'),
(8, 'Penda', 'sarr', '26-11-2002', 'Kaolack', 'Feminin', 'Vivant', '+221767456345', 'Babacar@gmail.com', 'Senegal/Dakar/Zac-mbao/', '14,6578575857-17,7375758484', 'éleve', '2022-11-21 18:48:51.000000', 1, '2022-11-21 18:48:51.000000', 'B34', 'Babacar  est un garçon qui vit dans le village de Konoah. Il rêve de devenir Hokage (un grand chef qui protège son village et qui est très puissant). Mais il est détesté de tout le monde, car il a un démon scellé en lui: le démon renard à neuf queues (Kyubi)');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Elements`
--
ALTER TABLE `Elements`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Elements`
--
ALTER TABLE `Elements`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
