<?php session_start(); ?>

<?php if (!isset($_SESSION['color'])): ?>
  <?php $_SESSION['color'] = 'rgba(34, 266, 7)'; ?>

<?php endif ?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title></title>
    <!-- lien font google -->
    <link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
    <!-- lien css bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- lien css local -->
    <!-- lien d'inclusion d'icone bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css.folder/index1.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  </head>
  <body style="background: black; font-family: Nunito;">

<div style="box-shadow: 0 0 20px 5px rgba(255, 255, 255, 0.10); margin-top: 70px; height: 500px; border-radius: 10px; " class="mx-auto col-12  col-sm-7 col-md-7 col-lg-5 col-xl-4 col-xxl-4">


   <div class="" style="margin-top: 60px;">
<center>
 
    

    <?xml version="1.0" encoding="UTF-8"?>
<svg style="filter: brightness(1.5);" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 150   150" width="150px" height="150px">
    <g id="surface147278652">

      <?php if($_SESSION['color'] !== 'red'): ?>
    <path style=" stroke:none;fill-rule:nonzero;fill:rgb(13.333334%,65.098041%,2.745098%);fill-opacity:1;" d="M 75 6 C 45.175781 6 21 14.0625 21 24 L 21 75 C 21 90.246094 37.253906 132.246094 75 141 C 112.746094 132.246094 129 90.246094 129 75 L 129 24 C 129 14.0625 104.824219 6 75 6 Z M 75 12 C 106.5 12 123 20.917969 123 24 L 123 75 C 123 87.410156 110.003906 121.570312 81 132.890625 L 81 114 L 69 114 L 69 132.890625 C 39.996094 121.570312 27 87.410156 27 75 L 27 24 C 27 20.917969 43.5 12 75 12 Z M 51 33 C 45.011719 33 38.566406 35.636719 33 45 C 38.859375 40.921875 43.839844 39 48 39 C 56.0625 39 60.082031 48.445312 61.3125 49.6875 C 63.070312 51.445312 65.917969 51.445312 67.6875 49.6875 C 69.445312 47.929688 69.445312 45.082031 67.6875 43.3125 C 66.585938 42.222656 61.3125 33 51 33 Z M 99 33 C 88.6875 33 83.414062 42.222656 82.3125 43.3125 C 80.554688 45.082031 80.554688 47.929688 82.3125 49.6875 C 84.082031 51.445312 86.929688 51.445312 88.6875 49.6875 C 89.917969 48.445312 93.9375 39 102 39 C 106.160156 39 111.140625 40.921875 117 45 C 111.433594 35.636719 104.988281 33 99 33 Z M 48 51 C 43.078125 51 38.753906 52.78125 36 55.5 C 38.753906 58.21875 43.078125 60 48 60 C 52.921875 60 57.246094 58.21875 60 55.5 C 57.246094 52.78125 52.921875 51 48 51 Z M 102 51 C 97.078125 51 92.753906 52.78125 90 55.5 C 92.753906 58.21875 97.078125 60 102 60 C 106.921875 60 111.246094 58.21875 114 55.5 C 111.246094 52.78125 106.921875 51 102 51 Z M 33 78 L 48 102 L 69 102 L 75 96 L 81 102 L 102 102 L 117 78 L 99 93 L 87 93 L 78 84 L 72 84 L 63 93 L 51 93 Z M 33 78 "/>

  <?php else: ?>

<path style=" stroke:none;fill-rule:nonzero;fill:rgb(98.431373%,6.666667%,6.666667%);fill-opacity:1;" d="M 75 6 C 45.175781 6 21 14.0625 21 24 L 21 75 C 21 90.246094 37.253906 132.246094 75 141 C 112.746094 132.246094 129 90.246094 129 75 L 129 24 C 129 14.0625 104.824219 6 75 6 Z M 75 12 C 106.5 12 123 20.917969 123 24 L 123 75 C 123 87.410156 110.003906 121.570312 81 132.890625 L 81 114 L 69 114 L 69 132.890625 C 39.996094 121.570312 27 87.410156 27 75 L 27 24 C 27 20.917969 43.5 12 75 12 Z M 51 33 C 45.011719 33 38.566406 35.636719 33 45 C 38.859375 40.921875 43.839844 39 48 39 C 56.0625 39 60.082031 48.445312 61.3125 49.6875 C 63.070312 51.445312 65.917969 51.445312 67.6875 49.6875 C 69.445312 47.929688 69.445312 45.082031 67.6875 43.3125 C 66.585938 42.222656 61.3125 33 51 33 Z M 99 33 C 88.6875 33 83.414062 42.222656 82.3125 43.3125 C 80.554688 45.082031 80.554688 47.929688 82.3125 49.6875 C 84.082031 51.445312 86.929688 51.445312 88.6875 49.6875 C 89.917969 48.445312 93.9375 39 102 39 C 106.160156 39 111.140625 40.921875 117 45 C 111.433594 35.636719 104.988281 33 99 33 Z M 48 51 C 43.078125 51 38.753906 52.78125 36 55.5 C 38.753906 58.21875 43.078125 60 48 60 C 52.921875 60 57.246094 58.21875 60 55.5 C 57.246094 52.78125 52.921875 51 48 51 Z M 102 51 C 97.078125 51 92.753906 52.78125 90 55.5 C 92.753906 58.21875 97.078125 60 102 60 C 106.921875 60 111.246094 58.21875 114 55.5 C 111.246094 52.78125 106.921875 51 102 51 Z M 33 78 L 48 102 L 69 102 L 75 96 L 81 102 L 102 102 L 117 78 L 99 93 L 87 93 L 78 84 L 72 84 L 63 93 L 51 93 Z M 33 78 "/>


  <?php endif ?>
    </g>
</svg>
 <form action="index.php" method="POST">
<div class="form-floating mb-3 col-9 mx-auto">
  <input name="pass" style="outline-color: transparent; color: <?php echo $_SESSION['color']; ?>; background: none; " type="password" class="input shadow-none form-control" id="floatingInput" placeholder="xxxhackxxx#$%*_)*(">
  <label style="color: none;" for="floatingInput">password</label>
</div>
<div class="form mb-3 col-9 mx-auto">
  <input type="submit" class="input-1" style="background: <?php echo $_SESSION['color']; ?>; " value="Intro">
  
</div>
</form>
</center>
   </div>
</div>
<style type="text/css">
  .input{
    box-shadow: none;
    border-radius: 0;
    border: 0.1px solid black;
    border-bottom: 2px solid <?php echo $_SESSION['color']; ?>;
outline: none;
  }
  .input-1{
    background: rgba(34, 166, 7, 1.0);
    border-radius: 10px;
    border: 2px solid transparent;
    width: 100%;
    height: 50px;
    text-align: center;
  }
</style>




 <!-- lien javascript boostrap -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="javascript.folder/index.js" defer ></script>

</body>
</html>




<?php if (isset($_POST['pass'])): ?>
  <?php if ($_POST['pass'] == 'Mwrhv.2004'): ?>
    <?php if ($_SESSION['color'] == 'red'): ?>
      <?php $_SESSION['color'] = 'rgba(34, 266, 7)'; ?>
      <?php $_SESSION['Acces_granted'] = true; ?>
      <?php if (isset($_SESSION['Acces_granted'])): ?>
        
      
      <script type="text/javascript">
        alert('Acces granted');
        document.location.href = 'data.folder';
      </script>
    <?php else: ?>
      <script type="text/javascript">
        alert('Acces permanently denied');
      </script>
      <?php endif ?>
    <?php endif ?>
     
    <?php else: ?>
   <?php $_SESSION['color'] = 'red'; ?>
      <script type="text/javascript">
        alert('Acces denied');
      </script>
  <?php endif ?>
<?php endif ?>