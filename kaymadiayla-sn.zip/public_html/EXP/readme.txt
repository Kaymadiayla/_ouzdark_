Explorateur de fichier en php-----------------------------
Url     : http://codes-sources.commentcamarche.net/source/32849-explorateur-de-fichier-en-phpAuteur  : akatopazDate    : 02/08/2013
Licence :
=========

Ce document intitul� � Explorateur de fichier en php � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un exemple rapide d'un explorateur de fichier en php avec miniature, possibili&e
acute; d'upload, de download (via http), de creation suppression de repertoire, 
du suppression de fichier.
<br />Les miniatures marche sur un systeme avec les 
extension, possibilt&eacute; de rajouter des miniatures par defaut dans un reper
toire prevu a cet effet.
<br />
<br />TODO : 
<br />======
<br /> - mise en 
place de l'autorisation avec les sessions (par tres compliqu&eacute;)
<br /> - 
gestion des style avec un css
<br /> - permettre l'edition de fichier texte (.t
xt, .htm[l], .php ...) en ligne
<br /><a name='conclusion'></a><h2> Conclusion 
: </h2>
<br />Voici la nouvelle version : <a href='http://tpz.ath.cx/desktop.t
ar.gz' target='_blank'>http://tpz.ath.cx/desktop.tar.gz</a>
