<!-- cette tache consite a supprimer aprés chaque 10minutes les verifications enregistré il-ya plus de 10minute -->
<?php include('../base.folder/linkbd.php'); ?>

<?php function delete_v($db, $id){
  $delete = $db->prepare('DELETE FROM Verification WHERE ID =?');
  $deleting = $delete->execute(array($id));
  return $deleting;
} ?>

<!-- supressions des anciennes verifications -->
<?php $requette = 'SELECT * FROM Verification'; ?>
<?php $delete = $db->prepare($requette); ?>
<?php $delete->execute(); ?>
<?php while($find = $delete->fetch()){ ?>
                <?php $date_request = $find['Date_enregistrement']; ?>
                <?php $hour_o = $find['Heure_enregistrement']; ?>
                <?php $year = substr($date_request, 0, 4); ?>
                <?php $month = substr($date_request, 5, 2); ?>
                <?php $day = substr($date_request, 8, 2); ?>
                <?php $hour = substr($hour_o, 0, 2); ?>            
                <?php $minut = substr($hour_o, 3, 2); ?> 

                <?php 
                if(date('Y') == $year){

                    if(date('m') == $month){

                        if(date('d') == $day){

                            if(date('H') == $hour){

                                $diff = date('i') - $minut;

                                if($diff > 5){
                                    $id = $find['ID'];
                                    delete_v($db, $id);
                                }else{
                                   
                                }

                            }else{?>
                           
                             <?php   $id = $find['ID'];
                                delete_v($db, $id);
                            }

                        }else{
                            $id = $find['ID'];
                            delete_v($db, $id);
                        }

                    }else{
                        $id = $find['ID'];
                        delete_v($db, $id);
                    }

                }else{
                    $id = $find['ID'];
                    delete_v($db, $id);
                }
                
                
                ?>
                 

    <?php } ?>

