<?php  $user = 'id19723717_ousmane_ndoye';
$pass = 'Mwrhv.ouzdark.2004';
try
{
	$db = new PDO('mysql:host=localhost;dbname=id19723717_utilisateurs;charset=utf8', $user, $pass,
[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
	
}
catch (PDOException $e)
{
        print('Erreur : ') . $e->getMessage() . "<br/>";
        die;
}

?>