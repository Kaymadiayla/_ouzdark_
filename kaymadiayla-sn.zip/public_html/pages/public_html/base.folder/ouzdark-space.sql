-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mar. 29 nov. 2022 à 12:35
-- Version du serveur :  10.5.16-MariaDB
-- Version de PHP : 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `id19723717_utilisateurs`
--

-- --------------------------------------------------------

--
-- Structure de la table `Classes`
--

CREATE TABLE `Classes` (
  `ID` int(11) NOT NULL,
  `Classe` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Date_de_creation` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `Valid` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Classes`
--

INSERT INTO `Classes` (`ID`, `Classe`, `Date_de_creation`, `Valid`) VALUES
(1, '1er S1', '2022-10-03 21:37:35.285930', 1),
(2, '1er L1', '2022-10-03 21:37:35.285930', 1),
(3, '1er L2', '2022-10-03 21:37:35.285930', 1),
(4, 'T S1', '2022-10-03 21:37:35.285930', 1),
(5, 'T S2', '2022-10-03 21:37:35.285930', 1),
(6, 'T L1', '2022-10-03 21:37:35.285930', 1),
(7, 'T L2', '2022-10-03 21:37:35.285930', 1),
(8, '2nd S', '2022-10-03 21:37:35.285930', 1),
(9, '2nd L', '2022-10-03 21:37:35.285930', 1),
(10, '1er S2', '2022-10-03 21:37:35.285930', 1),
(11, '3 eme', '2022-10-03 21:37:35.285930', 1),
(12, '4 eme', '2022-10-03 21:37:35.285930', 1),
(13, '5 eme', '2022-10-03 21:37:35.285930', 1),
(14, '6 eme', '2022-10-03 21:37:35.285930', 1);

-- --------------------------------------------------------

--
-- Structure de la table `Classes_prof`
--

CREATE TABLE `Classes_prof` (
  `ID` int(11) NOT NULL,
  `ID_professeur` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Classe` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Matiere` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Valid` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Classes_prof`
--

INSERT INTO `Classes_prof` (`ID`, `ID_professeur`, `Classe`, `Matiere`, `Valid`) VALUES
(1, '1', '1ere S1', 'Mathematique', 1),
(2, '1', '1ere S2', 'Francais', 1),
(3, '1', '2nd L', 'Espagnol', 1),
(4, '1', '2nd S', 'Anglais', 1);

-- --------------------------------------------------------

--
-- Structure de la table `Options1`
--

CREATE TABLE `Options1` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Value` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Valid` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Plugins_A`
--

CREATE TABLE `Plugins_A` (
  `ID` int(11) NOT NULL,
  `Aperçu` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `Statut` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `Auteur` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Vendu` int(1) NOT NULL DEFAULT 0,
  `Date_de_publication` date NOT NULL DEFAULT current_timestamp(),
  `Heure_de_publication` time(6) NOT NULL DEFAULT current_timestamp(),
  `Date_heure_publication` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Professeurs`
--

CREATE TABLE `Professeurs` (
  `ID` int(11) NOT NULL,
  `Prenom_du_professeur` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Nom_du_professeur` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date_enregistrement` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Professeurs`
--

INSERT INTO `Professeurs` (`ID`, `Prenom_du_professeur`, `Nom_du_professeur`, `Email`, `Date_enregistrement`) VALUES
(1, 'Ousmane', 'Ndoye', 'ousmane@gmail.com', '2022-10-04 11:47:36.000000'),
(2, 'Assane', 'Ndiaye', 'assane@gmail.com', '2022-10-04 11:47:36.000000');

-- --------------------------------------------------------

--
-- Structure de la table `Releve`
--

CREATE TABLE `Releve` (
  `ID` int(11) NOT NULL,
  `Nom_du_releve` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Date_de_creation` date NOT NULL,
  `Matiere_concerne` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Nom_du_professeur` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ID_professeur` int(200) NOT NULL,
  `Semmestre` int(1) DEFAULT NULL,
  `Trimestre` int(1) DEFAULT NULL,
  `Mois` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Annee` year(4) NOT NULL DEFAULT current_timestamp(),
  `Classe` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Releve`
--

INSERT INTO `Releve` (`ID`, `Nom_du_releve`, `Date_de_creation`, `Matiere_concerne`, `Nom_du_professeur`, `ID_professeur`, `Semmestre`, `Trimestre`, `Mois`, `Annee`, `Classe`) VALUES
(1, 'Devoir 1 du 1 semmestre', '2022-10-19', 'MATHEMATIQUES', 'Ousmane ndoye', 1, 1, 1, NULL, 2022, '1ere S1'),
(2, 'Devoir 1 du 1 semmestre', '2022-10-19', 'FRANÇAIS', 'Ousmane ndoye', 1, 1, 1, NULL, 2022, '1ere S2'),
(3, 'Devoir 1 du 1 semmestre', '2022-10-19', 'ANGLAIS', 'Ousmane ndoye', 1, 1, 1, NULL, 2022, '1ere S2'),
(4, 'Devoir 1 du 1 semmestre', '2022-10-19', 'ESPAGNOL', 'Ousmane ndoye', 1, 1, 1, NULL, 2022, '1ere S2');

-- --------------------------------------------------------

--
-- Structure de la table `Templates_A`
--

CREATE TABLE `Templates_A` (
  `ID` int(11) NOT NULL,
  `Aperçu` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `Statut` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `Auteur` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Vendu` int(1) NOT NULL DEFAULT 0,
  `Date_de_publication` date NOT NULL DEFAULT current_timestamp(),
  `Heure_de_publication` time(6) NOT NULL DEFAULT current_timestamp(),
  `Date_heure_publication` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `Templates_A`
--

INSERT INTO `Templates_A` (`ID`, `Aperçu`, `Description`, `Type`, `Statut`, `Auteur`, `Vendu`, `Date_de_publication`, `Heure_de_publication`, `Date_heure_publication`) VALUES
(1, 'Template.webp', 'Templates de sites E-commerce', 'S', 'D', 'Ousmane ndoye', 0, '2022-11-01', '19:55:10.000000', '2022-11-02 15:55:10.000000'),
(2, 'Template1.png', 'Templates de sites de vente', 'S', 'D', 'Ousmane ndoye', 0, '2022-11-01', '19:55:10.000000', '2022-11-02 15:55:10.000000');

-- --------------------------------------------------------

--
-- Structure de la table `Utilisateurs`
--

CREATE TABLE `Utilisateurs` (
  `ID` int(11) NOT NULL,
  `ID_messages` varchar(1000) NOT NULL DEFAULT 'no-values',
  `Prenom` varchar(1000) NOT NULL COMMENT 'Le prenom du chef d''etablissement',
  `Nom` varchar(1000) NOT NULL COMMENT 'Nom du chef d''etablissement',
  `Email` varchar(1000) NOT NULL,
  `Mot_de_passe` varchar(1000) DEFAULT NULL,
  `Username` varchar(1000) NOT NULL,
  `Preference` varchar(1000) NOT NULL,
  `Siege` varchar(1000) NOT NULL,
  `Date_inscription` date NOT NULL DEFAULT current_timestamp(),
  `Heure_inscription` time(6) NOT NULL DEFAULT current_timestamp(),
  `Valid` int(1) NOT NULL DEFAULT 1,
  `Ban` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `Utilisateurs`
--

INSERT INTO `Utilisateurs` (`ID`, `ID_messages`, `Prenom`, `Nom`, `Email`, `Mot_de_passe`, `Username`, `Preference`, `Siege`, `Date_inscription`, `Heure_inscription`, `Valid`, `Ban`) VALUES
(1, 'no-values', 'Ousmane', 'Ndoye', 'ousmandoye1234@gmail.comm', 'Mwrhv.2004', 'ousmandoye1234@gmail.comm', 'hhhh', 'jlnil', '2022-09-28', '55:58:18.000000', 1, 0),
(3, 'no-values', 'Nafissatou', 'Mbengue', 'merenafi.sn@gmail.com', NULL, 'Nafi1948', 'Publish', 'Pas de valeur', '2022-10-30', '14:54:34.000000', 1, 0),
(5, 'no-values', 'ousmane', 'ndoye', 'thiozthioz1@gmail.com', NULL, 'ousmanengh', 'Publicity', 'Pas de valeur', '2022-11-28', '18:22:33.000000', 1, 0),
(6, 'no-values', 'Ousmane', 'Ndoye', 'thiorrocompte@gmail.com', NULL, 'ousmane1', 'Vente', 'Pas de valeur', '2022-11-28', '18:35:21.000000', 1, 0),
(7, 'no-values', 'Ousmane', 'Ndoye', 'paousmandoye26nov2004@gmail.com', NULL, 'ousmane1', 'Vente', 'Pas de valeur', '2022-11-28', '18:51:52.000000', 1, 0),
(8, 'no-values', 'Mariame', 'coulibally', 'agenceimmobiliere04@gmail.com', NULL, 'user3343', 'Learning', 'Pas de valeur', '2022-11-28', '19:22:23.000000', 1, 0),
(9, 'no-values', 'Assane', 'Ndiaye', 'ousmandoye1234@gmail.com', 'ousseynou204', 'Assanengh54', 'Publicity', 'Pas de valeur', '2022-11-28', '19:26:51.000000', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `Verification`
--

CREATE TABLE `Verification` (
  `ID` int(11) NOT NULL,
  `ID_messages` varchar(1000) NOT NULL DEFAULT 'no-values',
  `Prenom` varchar(1000) NOT NULL COMMENT 'Le prenom du chef d''etablissement',
  `Nom` varchar(1000) NOT NULL COMMENT 'Nom du chef d''etablissement',
  `Email` varchar(1000) NOT NULL,
  `Mot_de_passe` varchar(1000) DEFAULT NULL,
  `Username` varchar(1000) NOT NULL,
  `Preference` varchar(1000) NOT NULL,
  `Siege` varchar(1000) NOT NULL,
  `Date_enregistrement` date NOT NULL DEFAULT current_timestamp(),
  `Heure_enregistrement` time(6) NOT NULL DEFAULT current_timestamp(),
  `DateTime` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `Code_de_verification` int(200) NOT NULL,
  `Valid` int(1) NOT NULL DEFAULT 1,
  `Ban` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `Verification`
--

INSERT INTO `Verification` (`ID`, `ID_messages`, `Prenom`, `Nom`, `Email`, `Mot_de_passe`, `Username`, `Preference`, `Siege`, `Date_enregistrement`, `Heure_enregistrement`, `DateTime`, `Code_de_verification`, `Valid`, `Ban`) VALUES
(106, 'no-values', 'Ousmane', 'Ndoye', 'oouz.dark@gmail.com', NULL, 'ousmane1', 'Vente', 'Pas de valeur', '2022-11-28', '19:16:34.000000', '2022-11-28 19:16:34.900741', 915328, 1, 0),
(109, 'no-values', 'Assane', 'Ndiaye', 'ousmaaandoye1234@gmail.com', NULL, 'Assanengh54', 'Publicity', 'Pas de valeur', '2022-11-28', '19:25:02.000000', '2022-11-28 19:25:02.298928', 185434, 1, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Classes`
--
ALTER TABLE `Classes`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Classes_prof`
--
ALTER TABLE `Classes_prof`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Options1`
--
ALTER TABLE `Options1`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Plugins_A`
--
ALTER TABLE `Plugins_A`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Professeurs`
--
ALTER TABLE `Professeurs`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Releve`
--
ALTER TABLE `Releve`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Templates_A`
--
ALTER TABLE `Templates_A`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Utilisateurs`
--
ALTER TABLE `Utilisateurs`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `Verification`
--
ALTER TABLE `Verification`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Classes`
--
ALTER TABLE `Classes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `Classes_prof`
--
ALTER TABLE `Classes_prof`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `Options1`
--
ALTER TABLE `Options1`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `Plugins_A`
--
ALTER TABLE `Plugins_A`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `Professeurs`
--
ALTER TABLE `Professeurs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `Releve`
--
ALTER TABLE `Releve`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `Templates_A`
--
ALTER TABLE `Templates_A`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `Utilisateurs`
--
ALTER TABLE `Utilisateurs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `Verification`
--
ALTER TABLE `Verification`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
