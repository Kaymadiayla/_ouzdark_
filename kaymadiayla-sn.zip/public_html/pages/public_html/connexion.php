<?php session_start(); ?>
<?php include('base.folder/linkbd.php'); ?>
<?php function get_current_url(){ ?>

<?php 
  if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
    $url = "https"; 
  else
    $url = "http"; 
    
  // Ajoutez // à l'URL.
  $url .= "://"; 
    
  // Ajoutez l'hôte (nom de domaine, ip) à l'URL.
  $url .= $_SERVER['HTTP_HOST']; 
    
  // Ajouter l'emplacement de la ressource demandée à l'URL
  $url .= $_SERVER['REQUEST_URI']; 
      
  // Afficher l'URL
  return $url; 
?>
<?php } ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- on inclus les liens css(boostrap, font-awessome); -->
    <?php include('link.folder/linkheader.php'); ?>
    <link rel="stylesheet" href="css.folder/connexion.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <title>Connexion.OuzdarkO</title>
</head>

<body>
<!-- 
<div class="toast">
  <div class="toast-header">
    Toast Header
  </div>
  <div class="toast-body">
    Some text inside the toast body
  </div>
</div>

    <script>
$(document).ready(function(){
  $('.toast').toast('show');
});
</script>
 -->
    <!-- logo -->
    <div id="logo" class="fs-4 text-center col-12">
        <span class="text-pi">Ouzdark</span><i alt="O" style="color: yellow;" class="fa-solid fa-leaf"></i>
    </div>

    <!-- fin de logo -->
    <!-- formulaire de connexion -->
    <div align="center"> <?php if(isset($_GET['back'])): ?> <i onclick="document.location.href='<?php echo $_GET['back']; ?>'"  class="fs-4 bi bi-arrow-left-circle"></i> <?php endif ?> </div>
    
    <div id="div" class="d-flex row col-10 col-sm-6 col-md-5 col-lg-5 col-xl-4">
        <form id="formualaire" action="<?php echo get_current_url(); ?>" method="POST">
            <div align="center" class="fs-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor"
                    class="bi bi-person-badge" viewBox="0 0 16 16">
                    <path style="color: yellow;"
                        d="M6.5 2a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3zM11 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                    <path style="color: #f14a69;"
                        d="M4.5 0A2.5 2.5 0 0 0 2 2.5V14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2.5A2.5 2.5 0 0 0 11.5 0h-7zM3 2.5A1.5 1.5 0 0 1 4.5 1h7A1.5 1.5 0 0 1 13 2.5v10.795a4.2 4.2 0 0 0-.776-.492C11.392 12.387 10.063 12 8 12s-3.392.387-4.224.803a4.2 4.2 0 0 0-.776.492V2.5z" />
                </svg>
            </div>
            <div align="center" class="text-gray">Connexion</div>
            <div style="margin-top: 30px;">
                <div class="form-floating mb-1">
                    <input id="emaili" name="Email_c" value="<?php if(isset($_SESSION['Email_Tp'])){ echo $_SESSION['Email_Tp']; } ?>"
                        type="email" class="email_i input form-control" id="floatingInput" placeholder="name@example.com">
                    <label for="floatingInput">Emal</label>
                    <span style="color: red; font-size: 13px;" class="mt-2 alert_email"></span>
                </div>
                <a style="visibility: hidden;" id="reset" href="connexion.php?rest=" class=" font-weight-bold text-pi">Recommencer</a>
                <!-- l'input qu'on doit afficher s'il existe un compte associer a l'email que l'utilisateur a entré -->
                <!-- il est invisible -->
                <div style="visibility: hidden; " class="mt-2 form-floating mb-3 ouz">
                    <input type="password" value="<?php if(isset($_SESSION['pwd_Tp'])){ echo $_SESSION['pwd_Tp']; } ?>" class="input oui form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Mot de passe</label>
                    <span class="alert_pass mt-2" style="color: red; font-size: 13px;"></span>
                </div>
               
                <div>
                    <button type="submit" name="connect" class="btn btn-pi float-right">Envoyer</button>
                </div>
            </div>
        </form>
    </div>



    <!-- fin de formulaire de connexion -->

    <!-- on insclus les liens javascript -->
    <?php include('link.folder/linkfooter.php'); ?>
</body>

</html>



<!-- traitement du formaulaire une fois les donnés sont envoyés -->

<?php if(isset($_POST['Email_c'])): ?>
   <?php unset($_SESSION['Email_T']) ?>
    <!-- si l'utilisateur poste l'email -->
    <!-- on recupere la valeur de l'email dans une session pour pouvoir le definir comme valeur par defaut de l'input sur l'aquelle on doit mettre l'email -->
    <?php $_SESSION['Email_Tp'] = trim($_POST['Email_c']); ?>
    <!-- en effet pour que cela s'applique il faut que la page s'actualise maintenant pour eviter ce la ont definira la valeur par defaut de l'input directement avec javascript -->
    <script>
    let input_email = document.querySelector('input.email');
    input_email.value = "<?php echo $_SESSION['Email_Tp']; ?>"
    </script>
    <?php if(!empty(trim($_POST['Email_c']))): ?>
    <?php $_SESSION['Email_T'] = trim($_POST['Email_c']); ?>
    <?php else: ?>
    <script>
    alert('Veuiller entrer un email valide');
    </script>
    <?php endif ?>
    <?php endif ?>
    <!-- on continue le traitement du formulaire -->
    <?php if(isset($_SESSION['Email_T'])): ?>



        <!-- on verifie s'il n'as pas entré de l'espace uniquement -->
<!-- on verifie si l'utilisateur est inscris -->
<?php $is_already_user = $db->prepare('SELECT * FROM Utilisateurs WHERE Email =? ORDER BY `ID` DESC LIMIT 1'); ?>
<?php $is_already_user->execute(array(trim(strtolower($_SESSION['Email_T'])))); ?>
<?php $is_user = $is_already_user->rowCount(); ?>



<?php if($is_user > 0): ?>
<!-- si l'email est incrite nous afficherons un second input sur laquelle l'utilisateur doit entrer l'input -->
<script>
let new_inputt = document.querySelector('input.oui');
let new_input = document.querySelector('div.ouz');
let input_emaili = document.querySelector('input#emaili');
input_emaili.readOnly = true;
new_input.style.visibility = 'visible';
new_inputt.setAttribute('name', 'pwd');
input_emaili.setAttribute('name', 'none');
</script>
<script>
    let link_reset = document.querySelector('a#reset');
    link_reset.style.visibility = 'visible';
</script>

<!-- si l'utilisateur a definis le mot de passe   -->
<?php if(isset($_POST['pwd'])): ?>
 <!-- si l'utilisateur renseigne le mot de passe -->
   <!-- on verifie si c'est exacte -->
     <?php while($result = $is_already_user->fetch()){ ?>
     <?php if($result['Ban'] == 0): ?>
      <?php if(trim($_POST['pwd']) == $result['Mot_de_passe']): ?>
        <!-- si le mot de passse est correct -->
        <?php $_SESSION['Email'] = $result['Email']; ?>
        <?php $_SESSION['Etablissement_name'] = $result['Nom_etablissement']; ?>
        <?php $_SESSION['Nom'] = $result['Nom']; ?>
        <?php $_SESSION['Prenom'] = $result['Prenom']; ?>
        <?php $_SESSION['Type'] = $result['Type_etablissement']; ?>
        
  <script>
    let principal = document.querySelector('div#div');
    principal.style.transitionDuration = '2s';
   setTimeout(function(){
    principal.style.filter = 'opacity(2%)';
    setTimeout(function(){
        document.location.href = 'Accueil.php';
    }, 1000)
   }, 1000)
  </script>
        <?php else: ?>
            <!-- si le mot de passe est incorrect -->
            <script>
    let alert_pass = document.querySelector('span.alert_pass');
    alert_pass.textContent = "Mot de passe incorrect";
  </script>
        <?php endif ?>
        <?php else: ?>
            <script>
    let alert_pass = document.querySelector('span.alert_pass');
    alert_pass.textContent = "Cette adresse email a été bannis pour des raisons de securité";
  </script>
        <?php endif ?>
        <?php } ?>

    <?php endif ?>

<?php else: ?>
<!-- si l'email n'est pas incrite nous afficherons un message d'alerte -->
<script>
let alert_email = document.querySelector('span.alert_email');
alert_email.textContent = "L'email n'est pas inscrite";
</script>
<?php if(isset($_SESSION['Email_T'])): ?>
    <?php unset($_SESSION['Email_T']); ?>
    <?php endif ?>
<?php endif ?>
        <?php endif ?>
        <?php if(isset($_GET['rest'])){
            if(isset($_SESSION['Email_T'])){
                unset($_SESSION['Email_T']);
                ?>
                <script>
                    document.location.href = "connexion.php";
                </script>
                <?php

            }
        } ?>


        <style>
 .text-pi{
        color: #f14a69;
    }
    .btn-pi{
        background: #f14a69;
        border: 2px solid #f14a69;
    }
</style>