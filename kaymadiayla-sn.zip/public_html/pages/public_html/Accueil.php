<?php session_start(); ?>
<?php $_SESSION['ID'] = '1'; ?>
<?php include('base.folder/linkbd.php'); ?>
<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('link.folder/linkheader.php'); ?>
    <link rel="stylesheet" href="https://unpkg.com/@popperjs/core@2">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link rel="stylesheet" href="css.folder/Accueil.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="javascript.folder/Accueil1.js" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>AccueiL-JIBIDO</title>
</head>
<body>
<!-- si l'utilisateur n'est pas connecté, nous l'obiligerons a le faire grace a l'obligation 1 -->
<!-- obligations 1 -->
<!-- on affichera une fenetre qui ne peux etre enlevée -->



<nav class="shadow mr-1 navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    <div id="logo" class="fs-4 text-center col-12">
            <span class="text-primary">JIBID</span><i alt="O" style="color: yellow;" class="fa-solid fa-leaf"></i>
        </div>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="ml-5 mr-3 collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Ecoles
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Classes</a></li>
            
            
          </ul>
        </li>
        <li class="nav-item">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Residants
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Professeurs</a></li>
            <li><a class="dropdown-item" href="#">Éléves</a></li>
            
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Publications
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Annoncer</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Reccher..." aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Rechercher</button>
      </form>
    </div>
  </div>
</nav>

<!-- Contenu du site -->
<div style="margin: 10px 0;"  class="container-fluid">
  
    <div class="mt-2">
        <div style="color: white;" class="fs-3 mb-2 font-weight-bold">
            Page de gestion
        </div>
        <div class=" conatainer-fluid row">
      <div style="padding: 20px; border-radius: 20px; box-shadow: 0 0 128px 0 rgba(0,0,0,0.1), 0 32px 64px -48px rgba(0,0,0,0.5); background: rgba(255, 255, 255, 0.5); " class="linear_animation col-11 col-sm-9 col-md-6 col-lg-5 col-xl-4 col-xxl-4">
      <div style="background: rgba(255, 255, 255, 0);">
     
     <!-- on recupere les classes creer par le surveillant ou le directeur -->
  <?php $option = $db->prepare("SELECT * FROM Classes WHERE Valid =?"); ?>
  <?php $option->execute(array('1')); ?>
  <?php $fetch = $option->rowCount(); ?>
  <?php $option = $option->fetchAll(); ?>
  <?php if($fetch > 0): ?>
    <!-- on recupere entre ces classes ceux qui sont enseignée par le professeur -->
    <?php $optionii = $db->prepare("SELECT * FROM Classes_prof WHERE ID_professeur =?"); ?>
  <?php $optionii->execute(array($_SESSION['ID'])); ?>
  <?php $fetchi = $optionii->rowCount(); ?>
  <?php $option = $optionii->fetchAll(); ?>
  <?php if($fetchi > 0): ?>
    <select style="border: none; background: rgba(255, 255, 255, 0.5);" class="form-select form-select-lg fs-6 mb-3" aria-label=".form-select-lg example">
      <!-- reste a securisée avec laravel -->
  <option <?php if(!isset($_GET['Classe']) AND !isset($_COOKIE['Classe'])){ echo 'selected'; } ?>><span class="fs-6" ><h6>Cliquer pour selectionner une classe</h6></span></option>
  
  <?php foreach($option as $option): ?>
    <?php $classe = $option['Classe']; ?>
  <option onclick="document.location.href=''" <?php if(isset($_GET['Classe']) OR isset($_COOKIE['Classe'])){ if(isset($_COOKIE['Classe'])){if($classe == $_GET['Classe']){ echo 'selected'; }}else{ if(isset($_GET['Classe'])){ if($classe == $_COOKIE['Classe']){ echo 'selected'; } } } }; ?> value="<?php echo $classe; ?>"> <a href="Accueil.php?Classe="><?php echo $classe; ?></a>  </option>
  <?php endforeach ?>
  </select>
  <?php else: ?>
   
    
    
    <div class="ml-3 mt-2" style="font-size: 13px; color: rgba(0, 0, 0, 0.4);">
            Aucune classe ne vous êtes attribuée, si vous pensez que ceci est une erreur alors contacter le surveillant ou le directeur.
            </div>
            <div style="height: 10px;">

    </div>
    <button class="ml-0 mb-3 btn btn-primary shadow-sm">Contaer</button>
  <?php endif ?>
  <?php else: ?>
    <div class="ml-3 mt-2" style="font-size: 13px; color: rgba(0, 0, 0, 0.4);">
            Le directeur n'as pas encore definis de classes.
            </div>
            <div style="height: 10px;">

    </div>
    <button class="ml-0 mb-3 btn btn-primary shadow-sm">Contaer</butto
  <?php endif ?>



  </div>
      <!-- on recupere les relevées existants -->
      
      <?php $recovery = $db->prepare("SELECT * FROM Releve WHERE ID_professeur =?"); ?>
      <?php $recovery->execute(array($_SESSION['ID'])); ?>
      <?php $found = $recovery->rowCount(); ?>
      
      <div style="border-radius: 20px; overflow-x: auto; overflow-y: hidden; background: rgba(255, 255, 255, 0);" class="d-flex container_fluid" id="statement_container">
      <?php if($found > 0): ?>
      
      <!-- on recupere toutes les resultat a l'aide d'un boucle -->
      
      <?php while($resultat = $recovery->fetch()){ ?>
        <div style="padding: 20px; padding-top: 1px; height: 100px; margin: 20px 20px; border-radius: 10px; box-shadow: 0 0 128px 0 rgba(0,0,0,0.1), 0 32px 64px -48px rgba(0,0,0,0.5); background: rgba(255, 255, 255, 0.5);" class="col-4">
         <span style="margin:0 auto ;"><i class="fs-1 text-primary bi bi-card-checklist"></i> <br> <sup class="fixed-top position-relative"><?php echo $resultat['Classe']; ?></sup></span>
         <br>
         <span></span>
        </div>
        <?php } ?>
        
        
   <center>
    
    </center>
   </span>
   </div>
   <div class="card-footer">
    <div style="height: 10px;">

    </div>
    
    <div>
<a class="shadow-sm btn btn-primary" href=""><i class="text-white bi bi-plus-circle-fill"></i>
&ensp; Creer un nouveau relevé
</a>
</div>
    
   </div>
         </div>
          </div>
          <?php else: ?>
            <div class="ml-3">
            <div class="mt-2 col-12 container-fluid" style="border: 1px solid gray; height: 0;">

            </div>
            
            <div class="mt-3 alert alert-primary" role="alert">
  Les relevés créée apparaitrons ici.
</div>
<div>
<a class="shadow-sm btn btn-primary" href=""><i class="text-white bi bi-plus-circle-fill"></i>
&ensp; Creer un nouveau relevé
</a>
</div>
</div>
        <?php endif ?>
      </div>
        </div>
       
    </div>
 
</div>

<script> 
$(document).ready(function(){
    
    $(".linear_animation").animate({marginLeft: '20px'}, "slow");
  
});
</script> 

</body>
</html>
<style>
  body{
    background: rgba(13, 110, 253, 1);
    background-repeat : no-repeat;
    background-size: cover;
    background-attachment: fixed;
    
  }
  /* menu du haut */
  .nav{
    box-shadow: 0 0 128px 0 rgba(0,0,0,0.1), 0 32px 64px -48px rgba(0,0,0,0.5); 
          
   position: fixed;
   top: 0;
   left: 0;
   right: 0;
  }
  .title{
    
  }
</style>

<script>
    
</script>