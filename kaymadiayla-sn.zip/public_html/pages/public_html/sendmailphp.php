

<?php
   $to = "ousmandoye1234@gmail.com";
   $subject = "Valider votre inscription chez JIBIDO";
 
   // In php 7.2 and newer versions we can use an array to set the headers.
   $headers = array(
    	'MIME-Version' => '1.0',
    	'Content-type' => 'text/html;charset=UTF-8',
    	'From' => 'ousmandoye1234@gmail.com',
    	'Reply-To' => 'ousmandoye1234@gmail.com'
   );
 
   // Setting the value in the $name variable.
   $name = "JIBIDO";
 
   // Starting output buffer.
   
   $message = 'message';
 
   
   $send = mail($to, $subject, $message, $headers);
 
   if(!$send){
      echo "Désolé le message n'as pas été envoyé (ERR1)";
   }else{
      $sent = true;
      echo "Message envoyé 1 avec succes";
   }
   $send = mail($to, $subject, $message, $headers);
 
if(!$send){
  echo "Désolé le message n'as pas été envoyé (ERR1)";
}else{
   if (!$sent) {
      echo "Message envoyé 1 avec succes";
      }
 
} ?>