<?php session_start(); ?>
<?php ob_start(); ?>
<!-- on inclu le fichier de connexion db -->
<?php if(isset($_POST['email'])){
    $_SESSION['Email_T'] = $_POST['email'];
} ?>
<?php include('base.folder/linkbd.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('link.folder/linkheader.php'); ?>
    <link rel="stylesheet" href="css.folder/inscription.css">
    <title>ouzdark</title>
</head>

<body>


    <center>
        <div id="logo" class="fs-4 text-center col-12">
            <span class="text-py">Ouzdark</span>
        </div>
    </center>
    <div style="overflow-x: hidden;" id="div" class="d-flex row col-10 col-sm-6 col-md-5 col-lg-5 col-xl-4">


        <!-- 

========================================================================
PREMIER FENETRE D'INSCRIPTION
========================================================================

 -->
        <div class="first">
            <div class="w-100 text-center" style="margin:0 auto;">
                <span>
                    <i class="bi bi-person-plus"></i>
                    <br>
                    S'inscrire
                    <br>
                    <span style="font-size: 13px;">
                        Une inscription est requise pour les achats et telechargements de templates, elle ne vous prendra que 30s
                    </span>
                    <hr>
                </span>
            </div>
            <!-- renseiger l'email -->
            <form onsubmit="" action="inscription.php" method="POST" class="input-g w-100 col-12">
                <input name="email" value="<?php if(isset($_SESSION['Email_T'])){ echo $_SESSION['Email_T']; } ?>"
                    style="padding-left: 10px; height: 40px;" placeholder="Email" type="email" class="input w-100">
                <span id="emailAlert"></span>
                <button name="valid" onclick="" type="submit" style="height: 40px;"
                    class="btn btn-py mt-2 float-right h-50">Envoyer</button>
                <div>

                </div>

            </form>
            <div style="height: 60px; width: 100%; border-bottom: 1px solid gray;">

            </div>
            <div class="text-center" style="font-size: 13px;">
                <div style="height: 20px;">

                </div>
                L'Email entré vous suivra tout au long de votre parcours sur <span class="text-py">Ouzdark</span>
               Elle vous permettra de sauvegarder des templates ou plugins deja achetés <br> <a class="text-py font-weight-bold" type="button" data-toggle="modal" data-target="#savoirplussurinscription" href="">En savoir
                    plus</a>
            </div>
            <div align="center">
  <?php if(isset($_SESSION['verify'])): ?>
    <a id="ccit" onclick="goToQuart()" class="text-py">Cliquez pour continuer votre inscription de tout a l'heure</a>
    <?php endif ?>
    </div>
    <a style="font-size: 13px;" class="text-py" href="connexion.php">Se connecter</a>
        </div>


        <!-- 

========================================================================
FIN PREMIER FENETRE D'INSCRIPTION////////////////////////////////
========================================================================

 -->




        <!-- 

========================================================================
DEUXIEME FENETRE D'INSCRIPTION
========================================================================

 -->
        <div style="height: 30px;" class="second">

        </div>
        <div class="">
            <span onclick="goToFirst()" style="margin:0 auto; font-size: 20px;"><i
                    class="bi bi-arrow-left-circle"></i></span> <br>
            <div class="w-100 text-center" style="margin:0 auto;">
                <span>
                    <i style="font-size: 20px;" class="bi bi-person-plus"></i>
                    <br>
                    Utilisateur
                    <br>
                    <span style="font-size: 13px;">
                        Ces informations ne concerne que l'utilisateur et serront essentiel tout au long de son parcours sur notre plate-forme (<span class="text-py">Ouzdark</span>).
                    </span>
                    <hr>
                </span>
            </div>
            <form onsubmit="" action="inscription.php" method="POST" class="w-100 col-12">
                <div class="form-row">
                    <div class="col-12 col-sm-7 col-md-7 mb-2">
                        <input value="<?php if(isset($_SESSION['prenom_T'])){ echo $_SESSION['prenom_T']; } ?>"
                            name="prenom" pattern="[a-zA-Z]{0,30}"
                            style="outline: yellow; padding-left: 10px; height: 40px;" placeholder="Prenom" type="text"
                            class="form-control">
                        <span class="alertPrenom"></span>
                    </div>

                    <div class="col-12 col-sm-5 col-md-5 mb-2">
                        <input value="<?php if(isset($_SESSION['nom_T'])){ echo $_SESSION['nom_T']; } ?>"
                            pattern="[a-zA-Z]{1,30}" name="nom" style="outline: none; padding-left: 10px; height: 40px;"
                            placeholder="Nom" type="text" class="form-control">
                        <span class="alertNom"></span>
                    </div>

                </div>


                <button name="valid2" onclick="" type="submit" style="height: 40px;"
                    class="btn btn-py mt-2 float-right h-50">Envoyer</button>
                <div>

                </div>

            </form>
            <div style="height: 60px; width: 100%; border-bottom: 1px solid gray;">

            </div>
            <div class="text-center" style="font-size: 13px;">
                <div style="height: 20px;">

                </div>
Veuiller remplir correctement ces informations.
            </div>
            <div align="center">
  <?php if(isset($_SESSION['verify'])): ?>
    <a id="ccit" onclick="goToQuart()" class="text-py">Cliquez pour continuer votre inscription de tout a l'heure</a>
    <?php endif ?>
    </div>
    <a style="font-size: 13px;" class="text-py" href="connexion.php">Se connecter</a>
        </div>



        <!-- 

========================================================================
FIN  DEUXIEME FENETRE D'INSCRIPTION//////////////////////////////
========================================================================
 -->







        <!-- 

========================================================================
TROISIEME FENETRE D'INSCRIPTION
========================================================================

 -->
        <br>
        <div style="height: 50px; margin-top: 20px;" class="thirst">

        </div>
        <div>
            <span onclick="goToSecond()" style="margin:0 auto; font-size: 20px;"><i
                    class="bi bi-arrow-left-circle"></i></span> <br>
            <div class="w-100 text-center" style="margin:0 auto;">
                <span>
                    <i style=" margin-top: 20px; font-size: 20px;" class="bi bi-file-break"></i>
                    <br>
                    Personnalisation
                    <br>
                    <span style="font-size: 13px;">
                        Ces informations nous permettrons de connaitre vos préfference, afin de d'ameliorer la na...

                    </span>
                    <hr>
                </span>
            </div>
            <form onsubmit="" action="inscription.php" method="POST" class="w-100 col-12">
                <div class="form-row">
                    <div class="col-12 col-sm-7 col-md-7 mb-2">
                        <input value="<?php if(isset($_SESSION['SN'])){ echo $_SESSION['SN']; } ?>" minlength="1"
                            maxlength="100" name="schoolName" style="padding-left: 10px; height: 40px;"
                            placeholder="Nom d'utilisateur" type="text" class="form-control">
                        <span style="color:red; font-size: 11px;" id="schoolNA"></span>
                    </div>

                    <div class="col-12 col-sm-5 col-md-5 mb-2">
                        <input value="Pas de valeur" minlength="5"
                            maxlength="100" name="schoolPlace" style="padding-left: 10px; height: 40px;"
                            placeholder="Lieu de siége" type="hidden" class="form-control">
                        <span id="schoolPA"></span>
                    </div>
                    <div class="col-12">
                                              <select name="level" style="color: gray; font-size: 17px;" placeholder="Niveau scolaire"
                            class="form-control form-control-lg">
                            <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'no'){ echo 'selected'; } ?>
                                value="no">Qu'est ce qui vous interesse ?</option>
                            <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'Vente'){ echo 'selected'; } ?>
                                value="Vente">La vente</option>
                            <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'Publicity'){ echo 'selected'; } ?>
                                value="Publicity">Les publicités</option>
                            <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'Publish'){ echo 'selected'; } ?>
                                value="Publish">Les publications</option>
                            <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'Learning'){ echo 'selected'; } ?>
                                value="Learning">L'enseignement</option>
                        </select>
                        <span class="level"></span>
                    </div>
                </div>


                <button onclick="" name="thistr" type="submit" style="height: 40px;"
                    class="btn btn-py mt-2 float-right h-50">Envoyer</button>
                <div>

                </div>

            </form>
            <div style="height: 60px; width: 100%; border-bottom: 1px solid gray;">

            </div>
            <div class="text-center" style="font-size: 13px;">
                <div style="height: 20px;">

                </div>
                Aprés le remplissage de ces informations nous vous enverrons un email de verification pour nous assurer
                qu'il sagit bien de vous
            </div>
            <div align="center">
  <?php if(isset($_SESSION['verify'])): ?>
    <a id="ccit" onclick="goToQuart()"  class="text-py">Cliquez pour continuer votre inscription de tout a l'heure</a>
    <?php endif ?>
    </div>
        </div>
        <div>
            <a style="font-size: 13px;" class="text-py" href="connexion.php">Se connecter</a>
        </div>




        <!-- +++===============================================================
FIN TROISIEME FENNETRE////////////////////////////////
=======================================================================-->




        <!-- +++===============================================================
FENETRE DE VERIFICATION
=======================================================================-->

        <div style="height: 309px;" class="quart">

        </div>
        <div class="info_window">
        <span onclick="goToThirst()" style="margin:0 auto; font-size: 20px;"><i
                    class="bi bi-arrow-left-circle"></i></span> <br>
            <div class="w-100 text-center" style="margin:0 auto;">
                <span>
                    <i style="font-size: 30px; color: #007bff;" class="bi bi-mailbox"></i>
                    <br>
                    Verification
                    <br>
                    <span style="font-size: 13px;">
                        Nous vous avons envoyé un email sur <strong><?php echo $_SESSION['Email_T']; ?></strong>. celui
                        ci contient votre code de
                        verification. En nous le renseignant, nous serrons capable de nous assurer qu'il s'agit bien de vous.
                        Vous pouvez egalement cliquer sur le lien de verification, á cette effet la verification serra
                        automatique.
                    </span>
                    <hr>
                </span>
            </div>
            <!-- renseiger l'email -->
            <form onsubmit="" action="inscription.php" method="POST" class="input-g w-100 col-12">
                <input pattern="[0-9]" name="vcode" value="<?php if(isset($_SESSION['vcode_e'])){ echo $_SESSION['vcode_e']; } ?>"
                    style="padding-left: 10px; height: 40px;" placeholder="Code reçu par Email" type="number"
                    class="inputi w-100">
                <span style="font-size: 12px; color: red;" id="vcodeAlert"></span>
                
                <button onfocus="this.name = 'verify'" name="verifi" onclick="" type="submit" style="height: 40px;"
                    class="btn btn-py mt-2 float-right h-50">Envoyer</button>
                    <button name="noReceive" onclick="" type="submit" style="margin: 7px 5px; background: yellow; height: 40px;"
                    class="btn text-white float-right h-50">Renvoyer le code</button>

                <div>

                </div>

            </form>
            <div style="height: 60px; width: 100%; border-bottom: 1px solid gray;">

            </div>
            <div class="text-center" style="font-size: 13px;">
                <div style="height: 20px;">

                </div>
                Votre code de verifications n'est valide que pour 10 minutes. Si celui est déja expiré nous vous prions
                de redemandais un nouveau code. <br> <a class="text-py font-weight-bold" href="">En savoir
                    plus</a>
            </div>
        </div>


        <!-- +++===============================================================
FIN  FENETRE DE VERIFICATION //////////////////////////////
=======================================================================-->
    </div>
    






    <div style="visibility: hidden;" class="">
        <div class="circle">

        </div>
    </div>

    <style>
    .circle {

        border-bottom: yellow 4px solid;
        border-radius: 50%;
        width: 70px;
        height: 70px;
        border-top: #007bff 4px solid;
        border-left: 4px solid white;
        border-right: 4px solid white;
        animation: loadert 5s linear infinite;
    }
    </style>
    <script>
    let circle = document.querySelector('div.circle');
    document.querySelector('div.circle').style.transitionDuration = '60s';
    setInterval(function() {
        circle.style.transform = 'rotate(92260deg)';



    }, 500)
    </script>

    <?php include('link.folder/linkfooter.php'); ?>
    <script src="javascript.folder/inscription.js" defer></script>


</body>

</html>
<script>
function goToSecond() {
    var elem = document.querySelector('div.second');
    elem.scrollIntoView();

}

function goToThirst() {

    var elem = document.querySelector('div.thirst');
    elem.scrollIntoView();

}

function goToQuart() {
    var elem = document.querySelector('div.info_window');
    elem.scrollIntoView();
}


function goToFirst() {

    $('#div').scrollTop(1)
}
</script>
<!-- traitement du formulaire de la fenetre 1 -->

<?php  if(isset($_POST['email'])): ?>
<?php if(!empty(trim($_POST['email']))): ?>
<?php $_SESSION['Email_T'] = $_POST['email']; ?>
<?php if(isset($_SESSION['Email_T'])): ?>
<?php include('base.folder/linkbd.php'); ?>
<?php include('function.folder/inscription_function.php'); ?>
<?php $is_user = is_user($db, $_SESSION['Email_T']); ?>
<?php $execution = $is_user['execution']; ?>
<?php $find_u = $is_user['find_user']; ?>
<?php if($execution): ?>
<?php if($find_u == 0): ?>
<script>
var elem = document.querySelector('div.second');
elem.scrollIntoView();
goToSecond();
</script>
<?php else: ?>
<script>
let alert_for_email = document.querySelector('span#emailAlert');
alert_for_email.textContent = 'L\'email est déja inscrite';
</script>
<?php endif ?>


<?php else: ?>
<script>
alert('Une erreur est survenu lors de la verification vueiller re-essayer');
</script>
<?php endif ?>

<?php else: ?>
<script>
alert('une erreur est survenu lors du traitement du formulaire vueiller re-essayer  ')
</script>
<?php endif ?>
<?php else: ?>
<script>
let alert_for_email = document.querySelector('span#emailAlert');
alert_for_email.textContent = 'Email invalide';
</script>
<?php endif ?>
<?php endif ?>




<!-- traitement du formulaire de la fenetre 2 -->

<?php  if(isset($_POST['prenom'])): ?>
<?php if(!empty(trim($_POST['prenom']))): ?>
<?php $_SESSION['prenom_T'] = trim($_POST['prenom']); ?>
<?php if(isset($_SESSION['prenom_T'])): ?>
<?php  if(isset($_POST['nom'])): ?>
<?php if(!empty(trim($_POST['nom']))): ?>
<?php $_SESSION['nom_T'] = trim($_POST['nom']); ?>
<?php if(isset($_SESSION['nom_T'])): ?>
<script>
var elem = document.querySelector('div.thirst');
elem.scrollIntoView();
</script>
<?php else: ?>
<script>
alert('une erreur est survenu lors du traitement du formulaire vueiller re-essayer  ')
</script>
<?php endif ?>
<?php else: ?>
<script>
let alert_for_nom = document.querySelector('span#emailNom');
alert_for_nom.textContent = 'Nom invalide';
</script>
<?php endif ?>
<?php endif ?>
<?php else: ?>
<script>
alert('une erreur est survenu lors du traitement du formulaire vueiller re-essayer  ')
</script>
<?php endif ?>
<?php else: ?>
<script>
let alert_for_prenom = document.querySelector('span#emailPrenom');
alert_for_prenom.textContent = 'Prenom invalide';
</script>
<?php endif ?>
<?php endif ?>

<!-- traitement du troisieme formulaire -->
<?php if(isset($_POST['schoolName'])): ?>
<?php $_SESSION['SN'] = trim($_POST['schoolName']); ?>
<?php $_SESSION['level'] = trim($_POST['level']); ?>
<?php $_SESSION['SP'] = trim($_POST['schoolPlace']); ?>
<?php if(!empty(trim($_POST['schoolName']))): ?>
<?php if(isset($_POST['schoolPlace'])): ?>

<?php if(!empty(trim($_POST['schoolPlace']))): ?>
<?php if(isset($_POST['level'])): ?>
<?php if($_POST['level'] != 'no'): ?>
<?php include('base.folder/linkbd.php'); ?>
<?php include('function.folder/inscription_function.php'); ?>
<?php $exec_p = insert($db); ?>
<?php $exec = $exec_p['execution']; ?>
<?php $is_sendable = $exec_p['sendable']; ?>
<?php if($exec){
 ?>
<?php if($is_sendable){ ?>
<?php if(sendmail($_SESSION['Email_T'])){ ?>
<?php unset($_SESSION['vcode']); ?>
<script>
alert('Nous venons de vous envoyer une email de verification');
</script>
<script>
    goToQuart();
</script>
<?php } else { ?>
<script>
alert('Une erreur est survenu lors de l\'envoie du mail veuiller re-essayer');
</script>
<?php }; ?>
<?php }else{ ?>
    <script>
        goToQuart();
    </script>
<?php }
                  }else{?>
<script>
alert('une erreur est survenu lors de l\'enregistrement des données');
</script>
<?php } ?>

<?php else: ?>
<script>
let alert_for_level = document.querySelector('span.level');
alert_for_level.textContent = 'Il est important pour nous de savoir cet information';
var elemm = document.querySelector('div.thirst');
elemm.scrollIntoView();
</script>
<?php endif ?>
<?php endif ?>
<?php else: ?>

<?php endif ?>
<?php endif ?>
<?php else: ?>
<script>
let alert_for_schoolName = document.querySelector('span#schoolNA');
alert_for_schoolName.textContent = 'Veuiller entrer un nom d\'utilisateur valide ';
alert_for_schoolName.style.fontSize = '11px';
alert_for_schoolName.style.color = 'red';
var elem = document.querySelector('div.thirst');
elem.scrollIntoView();
</script>
<?php endif ?>
<?php endif ?>



<!-- traitement du formulaire de verification (FORMULAIRE 4); -->
<?php if(isset($_POST['verify'])): ?>
    <?php $_SESSION['vcode_e'] = trim($_POST['vcode']); ?>
<?php if(isset($_POST['vcode'])): ?>
<!-- si l'utilisateur entre le code de verification -->

<!-- on verifie si l'utilisateur a demander de code de verification -->
<?php include('base.folder/linkbd.php'); ?>
<?php $verify = $db->prepare('SELECT * FROM Verification WHERE Email =?'); ?>
<?php $exec_ = $verify->execute(array($_SESSION['Email_T'])); ?>
<?php $verify_fetch = $verify->rowCount(); ?>
<?php if($exec_): ?>
<?php if($verify_fetch > 0): ?>
 <?php $verify = $db->prepare('SELECT * FROM Verification WHERE Email =? AND Code_de_verification =?'); ?>
<?php $exec_ = $verify->execute(array($_SESSION['Email_T'], trim($_POST['vcode']))); ?>
<?php $verify_fetch = $verify->rowCount(); ?>
<?php if($verify_fetch > 0): ?>
    <!-- on enregistre comme utilisateurs -->
    <?php include('function.folder/inscription_function.php'); ?>
    <?php if(create_user($db)['execution']): ?>
        <?php delete_demand($db); ?>
        <?php if(isset($_SESSION['Email_T'])): ?>
        <?php $_SESSION['Email'] = $_SESSION['Email_T']; ?>
        <?php if(isset($_SESSION['Email'])): ?>
             <?php $_SESSION['create_pass'] = true; ?>
            <?php header("location:http://ouzdark.space/bienvenue.php?new=1"); ?>
        <?php endif ?>
    <?php else: ?>
        <script type="text/javascript">
            alert('Nous allons re-actualiser la page pour essayer de ressoudre un probléme');
            document.location.reload();
        </script>
    <?php endif ?>
    <?php else: ?>
        <script type="text/javascript">
            alert('une erreur est survenu lors de l\'enregistrement de vos données');
        </script>
    <?php endif ?>
    <script>
goToQuart();
</script>
    <?php else: ?>
        
        <script>
        alert('Veuiller reverifier votre code, est-ce réellement correcte ?');
        document.querySelector('input.inputi').value = '<?php echo $_SESSION['vcode_e']; ?>';
        
    </script>
    <script>
goToQuart();
</script>
    <?php endif ?>
    <?php else: ?>
        <script>
goToQuart();
</script>
        <script>
            let alert_code = document.querySelector('span#vcodeAlert');
            alert_code.textContent = 'Etes vous sur d\'avoir reçu un email de verification; si c\'est bien le cas alors ce dernier semble expiré et qu\'il vas falloir en redemander';
        </script>
    <?php endif ?>
    <?php else: ?>
    <!-- si l'execution n'as pas bien deroulé -->
    <script>
        alert('Une erreur est survenu lors de la verification, veuiller re-essayer');
    </script>
    <script>
goToQuart();
</script>
    <?php endif ?>
    <?php else: ?>
        <script>
            alert('Veuiller re-essayer');
        </script>
        
<?php endif ?>
<?php endif ?>



<!-- si l'utilisateur accede a cette page depuis le lien de son mail on mets a jour les informations pour qu'ils puisse continuer sa verifications mais on verifie d'abord est ce qu'il a demander un email de verification  -->
<?php if(isset($_GET['email'])): ?>
    <?php $_SESSION['Email_T'] = trim($_GET['email']); ?>
    <?php if(isset($_GET['vcode'])): ?>
        <?php $_SESSION['vcode_e'] = trim($_GET['vcode']); ?>

        <!-- on verifie si l'utilisateur a demander un email de verification -->
        <?php include('base.folder/linkbd.php'); ?>
        <?php $_veri = $db->prepare('SELECT * FROM Verification WHERE Email =?'); ?>
        <?php $_veri->execute(array(strtolower($_SESSION['Email_T']))); ?>
        <?php $_veri_f = $_veri->rowCount(); ?>
        <?php if($_veri_f > 0): ?>
            <?php $verify = $db->prepare('SELECT * FROM Verification WHERE Email =? AND Code_de_verification =?'); ?>
<?php $exec_ = $verify->execute(array($_SESSION['Email_T'], trim($_SESSION['vcode_e']))); ?>
<?php $verify_fetch = $verify->rowCount(); ?>
<?php if($verify_fetch > 0): ?>
     <!-- on enregistre comme utilisateurs -->
    <?php if(create_user($db)['execution']): ?>
        <?php delete_demand($db); ?>
        <?php if(isset($_SESSION['Email_T'])): ?>
        <?php $_SESSION['Email'] = $_SESSION['Email_T']; ?>
        <?php if(isset($_SESSION['Email'])): ?>
            <?php $_SESSION['create_pass'] = true; ?>
            <?php header("location:http://ouzdark.space/bienvenue.php?new=1"); ?>
        <?php endif ?>
    <?php else: ?>
        <script type="text/javascript">
            alert('Nous allons re-actualiser la page pour essayer de ressoudre un probléme');
            document.location.reload();
        </script>
    <?php endif ?>
    <?php else: ?>
        <script type="text/javascript">
            alert('une erreur est survenu lors de l\'enregistrement de vos données');
        </script>
    <?php endif ?>

    <?php else: ?>
        <script>
        alert('Veuiller reverifier votre code, est-ce réellement correcte ?');
    </script>
    <?php endif ?>
            <?php else: ?>
                <script>
                    var elemm = document.querySelector('div.second');
                    elemm.scrollIntoView();
                </script>
            <?php endif ?>
        <?php endif ?>
    <?php endif ?>


<!-- si l'utilisateur redemande un nouveau mail parcequ'il; n'as pas reçu l'autre -->
<?php if(isset($_POST['noReceive']) AND !isset($_POST['verifi']) ): ?>
<?php include('base.folder/linkbd.php'); ?>
<?php include('function.folder/inscription_function.php'); ?>
<?php $exec_p = insert($db); ?>
<?php $exec = $exec_p['execution']; ?>
<?php $is_sendable = $exec_p['sendable']; ?>
<?php if($exec){
 ?>
<?php if($is_sendable){ ?>
    
<?php if(sendmail($_SESSION['Email_T'])){ ?>
<?php unset($_SESSION['vcode']); ?>
<script>
alert('Nous venons de vous envoyer une email de verification');
</script>
<script>
goToQuart();
</script>
<?php } else { ?>
<script>
alert('Une erreur est survenu lors de l\'envoie du mail veuiller re-essayer');
</script>
<script>
goToQuart();
</script>
<?php }; ?>
<?php } ?>
<?php
                  }else{?>
<script>
alert('une erreur est survenu lors de l\'enregistrement des données');
</script>
<script>
goToQuart();
</script>
<?php } ?>
<?php endif ?>


   
    <!-- si l'email de verifications a été envoyé avec succés -->
<?php if(isset($_SESSION['sended'])){
 if($_SESSION['sended']){ ?>
 <?php $_SESSION['verify'] = 1; ?>
<script>
goToQuart();
</script>
  <?php unset($_SESSION['sended']); ?>
<?php }
} ?>
<style>
    #ccit{
        font-weight: 600;
        font-size: 13px;
        margin-top: 30px;
    }
    .text-py{
        color: #f14a69;
    }
    .btn-py{
        background: #f14a69;
        border: none;
        color: white;
    }
    .btn{
        color: white;
    }
</style>




<!-- ++====================================
    EN SAVOIR PLUS
============================================ -->

<!-- +++++================== 1 -->




<!-- Modal -->
<div class="modal fade" id="savoirplussurinscription" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">L'importance d'avoir un compte</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        En effet, pour les membres nous sauvegarderons leurs templates ou plugins aprés chaques achats, pour leurs donner la possibilité de l'obtenir de nouveau une fois le document perdu.
        Mais celle ci ne sera suavegarder que pour une durée bien detreminée (1 an). <br>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        
      </div>
    </div>
  </div>
</div>