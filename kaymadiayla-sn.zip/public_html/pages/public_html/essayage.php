                                              <?php include('base.folder/linkbd.php'); ?>
                                               <select name="level" style="color: gray; font-size: 17px;" placeholder="Niveau scolaire"
                            class="form-control form-control-lg">
                            <!-- on recupere les options créée dans la base de donnée -->
                            <?php $requette = $db->prepare('SELECT * FROM Options1 WHERE Valid = ?'); ?>
                            <?php $execution = $requette->execute(array('1')); ?>
                          <?php if ($execution): ?>
                              
                         <?php while($result = $requette->fetch()){ ?>
                              <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == $result['Nom']){ echo 'selected'; } ?>
                                value="no"></option>

                         <?php } ?>

                        <?php else: ?>  
                                     <option
                                <?php if(isset($_SESSION['level']) AND $_SESSION['level'] == 'no'){ echo 'selected'; } ?>
                                value="no">Veuiller re-actualiser la page pour voir les options diponibles</option>

                                 <?php endif ?>
                                                   </select>