<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<script src="https://kit.fontawesome.com/f2b6543989.js" crossorigin="anonymous"></script>
	<style>
		.inscription{
			background: white;
			background-color: white;
			 box-shadow: 0 0 128px 0 rgba(0,0,0,0.1),
             0 32px 64px -48px rgba(0,0,0,0.5); 
			 height: 500px;
			 width: 400px;
			 margin: 0 auto;
			 margin-top: 50px;
			 padding: 20px 10px;
			 font-family: Poppins, Arial, Helvetica, sans-serif;
			 padding-left: 20px;
			 
		}
		.body{
			background: white;
			background-color: white;
		}
		.bonjour{
           
		   font-size: 20px;
		   font-family: Poppins, Arial, Helvetica, sans-serif;
		   margin-bottom: 20px;
		}
		.user-name{
			color: #007bff;
		}
		#logo{
			color:#007bff;
			margin-bottom: 20px;
			font-size: 30px;
		
		}
		.vcodeBox{

			margin: 10px auto;
			text-align: center;
			font-weight: 600;
		}
		.vcodeText{
			color: gray;
			font-size: 20px;
			margin: px auto;
		}
		.vcode{
			
			color: #007bff;
		}
		.link{
			text-decoration: none;
			font-size: 12px;
		}
		a{
			text-decoration: none;
		}
	</style>
</head>
<body class="body">
	

<div class="inscription">
	<center>
	<div id="logo" class="fs-4 text-center col-12">
		<span class="text-primary">Ouzdark</span><i alt="O" style="color: yellow;" class="fa-solid fa-leaf"></i>
	</div>
</center>
<div class="bonjour">
	Bonjour
	<span class="user-name">
Ousmane
	</span>
</div>
<div><span style="font-size: 12px;">
Nous sommes trés heureux qu'une nouvelle personne ait rejoint notre communauté. <br>
Bon!, suite a votre demande d'inscription chez <a href="#">Ouzdark</a> nous vous envoyons cet Email pour verifier qu'il s'agit bien de vous. <br>
Pour cette verification il n'y-a rien de plus simple que de nous renseigner le code verification suivant dont la page dont le lien d'accés sera ci-contre.
</span> <br>
<div class="vcodeBox">
<span class="vcodeText">Code de verification </span>
<br>
<span class="vcode">345-456</span>
<br>
<a class="link" href="#page de verification">Page de verification</a>

</div>
Vous étes paresseux de faire tout cela ? On a tout prévu, dans ce cas cliquer sur le lien de verification ci dessous pour verifier de façons automatique votre identité<div class=""></div>
<div class="vcodeBox">
	
	<a class="link" href="#page de verification">Cliquer ici pour verifiver votre identité</a>
	
	</div>
</div>
</div>


</body>
</html>