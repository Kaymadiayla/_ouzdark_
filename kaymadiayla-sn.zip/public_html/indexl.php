<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
	<title>Pour moustapha aidara</title>
</head>
 
<body style="


color: #245E7E; font-family: Nunito;">
	
<style type="text/css">
	.img1{
		margin-top: -600px;
		border-radius: 15px;
		box-shadow: 0 0 138px 0 rgba(0,0,0,0.1), 0 32px 64px -48px rgba(0,0,0,0.5);
	}
</style>


	<div style="margin-left: -10px;" align="center" class="img1">
		<br>
		<center><img width="110px" height="auto" style="border-radius:45%;" src="aidara.jpg"></center>
		
		<h3>HBD Moustapha aidara</h3>
		
		<img class="img1" width="300px" height="auto" src="https://cakewithname.net/thumbnail/Mustapha/130/candles-decorated-happy-birthday-cake-for-Mustapha.jpg">
		<br>
		<br>
		<audio id="myAudio" controls autoplay>
  <source src="media/images/birth.ogg" type="audio/ogg">
  <source src="media/images/birth.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio>
	</div>


	<script type="text/javascript">
		alert('Joyeux anniversaire Moustapha aidara');
		
 var audio=document.createElement('audio');
 var first=true;
     
 
    function onmousedown(){
       if(!first) return;
       first=false;
       audio.src="media/images/birth.mp3";
       audio.autoplay = true;
    }
onmousedown();

  var div3 = document.querySelector('img.img1');
 setTimeout(function(){
    div3.style.transitionDuration = '1.3s';
    div3.style.transform = 'translateY(300px)';

   },100) 
     setInterval(function(){
    div3.style.transitionDuration = '1.3s';
    div3.style.transform = 'translateY(370px)';
     setTimeout(function(){
    div3.style.transitionDuration = '1.3s';
    div3.style.transform = 'translateY(300px)';
   },100 ) ;
   },100 ) ;
	</script>

<style type="text/css">
	.img1 {  
    animation-name: object;
    animation-duration: 3s;
    animation-iteration-count: infinite;
    animation-timing-function: ease-in-out;
    margin-left: 30px;
    margin-top: 5px;
}

@keyframes object {
    from { transform: translate(0,  0px); }
    65%  { transform: translate(0, 15px); }
    to   { transform: translate(0, -0px); }    
}
</style>



</body>
</html>